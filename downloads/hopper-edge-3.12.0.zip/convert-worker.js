// Runs ffmpeg entirely inside the extension. The wasm build is single-threaded
// because extension pages are not cross-origin isolated, so SharedArrayBuffer
// is unavailable; that is also why this worker is started per job instead of
// being shared. The popup terminates it to cancel.
//
// Messages in:  { type: "run", id, kind: "convert", buffer, input, format, quality, start, end }
//               { type: "run", id, kind: "merge", clips: [{ input, buffer, ...metadata }], format, quality }
// Messages out: { type: "progress", id, percent, seconds }
//               { type: "done", id, buffer, mime }
//               { type: "error", id, message }

import createFFmpegCore from "./vendor/ffmpeg-core/ffmpeg-core.js";
import { planConversion } from "./convert-plan.js";
import { planMerge } from "./merge-plan.js";

const CORE_BASE = new URL("./vendor/ffmpeg-core/", import.meta.url);

let corePromise = null;
let job = null;
let log = [];

function post(message, transfer) {
  self.postMessage(message, transfer || []);
}

function loadCore() {
  if (!corePromise) {
    corePromise = createFFmpegCore({
      locateFile: (file) => new URL(file, CORE_BASE).href,
      print: (line) => readLine(line),
      printErr: (line) => readLine(line),
    }).then((core) => {
      core.setLogger((entry) => readLine(entry && entry.message));
      return core;
    });
    corePromise.catch(() => {
      corePromise = null;
    });
  }
  return corePromise;
}

function readLine(line) {
  if (!job || typeof line !== "string") return;

  if (line.trim()) {
    log.push(line);
    if (log.length > 40) log.shift();
  }

  // ffmpeg prints "Duration: 00:00:03.00" once for the input, before any
  // progress. Without it the bar stays indeterminate rather than inventing a
  // percentage.
  if (!job.duration) {
    const found = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(line);
    if (found) job.duration = Number(found[1]) * 3600 + Number(found[2]) * 60 + Number(found[3]);
  }

  const time = /time=\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(line);
  if (!time) return;
  const seconds = Number(time[1]) * 3600 + Number(time[2]) * 60 + Number(time[3]);
  job.seconds = seconds;
  if (!job.duration) return;

  const percent = Math.max(0, Math.min(99, Math.round((seconds / job.duration) * 100)));
  if (percent === job.percent) return;
  job.percent = percent;
  post({ type: "progress", id: job.id, percent, seconds });
}

function tail() {
  const text = log.join(" ").replace(/\s+/g, " ").trim();
  return text.length > 240 ? text.slice(-240) : text;
}

function prepare(message) {
  const { format, quality, start, end } = message;

  if (message.kind === "merge") {
    const clips = (message.clips || []).map(({ buffer, ...clip }) => clip);
    return {
      plan: planMerge({ format, quality, clips }),
      files: (message.clips || []).map((clip) => ({ name: clip.input, buffer: clip.buffer })),
    };
  }

  const input = message.input || "input.media";
  return {
    plan: planConversion({ format, quality, start, end, input }),
    files: [{ name: input, buffer: message.buffer }],
  };
}

async function run(message) {
  const { id, kind = "convert" } = message;
  let core = null;
  let plan = null;
  let files = [];
  log = [];

  try {
    const prepared = prepare(message);
    plan = prepared.plan;
    files = prepared.files;
    core = await loadCore();

    job = { id, duration: plan.expectedDuration || 0, percent: -1, seconds: 0 };

    const names = files.map((file) => file.name);
    names.push(plan.output);

    const remove = () => {
      for (const name of names) {
        try {
          core.FS.unlink(name);
        } catch {
          /* not created or already gone */
        }
      }
    };

    remove();
    for (const file of files) {
      core.FS.writeFile(file.name, new Uint8Array(file.buffer));
    }

    const code = core.exec(...plan.args);
    if (code !== 0) {
      throw new Error(`ffmpeg stopped with code ${code}. ${tail()}`.trim());
    }

    const output = core.FS.readFile(plan.output);
    if (!output || output.length === 0) {
      throw new Error(kind === "merge" ? "The merge produced an empty file." : "The conversion produced an empty file.");
    }

    const copy = output.slice();
    post({ type: "done", id, buffer: copy.buffer, mime: plan.mime }, [copy.buffer]);
    remove();
  } catch (error) {
    post({
      type: "error",
      id,
      message: error && error.message ? error.message : "The job failed.",
    });
  } finally {
    job = null;
    log = [];
  }
}

self.addEventListener("message", (event) => {
  const message = event.data;
  if (!message || message.type !== "run") return;
  void run(message);
});
