// File classification and metadata for the File tab. Everything here runs in
// the popup; nothing is sent anywhere.

export const KNOWN_EXTENSIONS = new Set([
  "mp4",
  "webm",
  "mov",
  "mkv",
  "m4v",
  "avi",
  "mp3",
  "m4a",
  "aac",
  "wav",
  "ogg",
  "opus",
  "flac",
]);

const AUDIO_EXTENSIONS = new Set(["mp3", "m4a", "aac", "wav", "ogg", "opus", "flac"]);

export function fileKind(file) {
  if (file.type.startsWith("audio/")) return "audio";
  if (file.type.startsWith("video/")) return "video";
  return AUDIO_EXTENSIONS.has(extensionOf(file.name)) ? "audio" : "video";
}

export function isKnownMedia(file) {
  if (file.type.startsWith("video/") || file.type.startsWith("audio/")) return true;
  return KNOWN_EXTENSIONS.has(extensionOf(file.name));
}

/** 3.4 -> "3.4s", 65 -> "1:05", 3600 -> "1:00:00". */
export function formatDuration(seconds) {
  const value = Number(seconds);
  if (!Number.isFinite(value) || value <= 0) return "0:00";
  if (value < 60) return `${value.toFixed(1)}s`;
  return formatClock(value);
}

/** 3.4 -> "0:03", 65 -> "1:05", 3600 -> "1:00:00". */
export function formatClock(seconds) {
  const value = Number(seconds);
  if (!Number.isFinite(value) || value <= 0) return "0:00";
  const whole = Math.floor(value);
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const rest = whole % 60;
  if (hours) return `${hours}:${String(minutes).padStart(2, "0")}:${String(rest).padStart(2, "0")}`;
  return `${minutes}:${String(rest).padStart(2, "0")}`;
}

/**
 * Reads duration, frame size and track presence without playing the file.
 * captureStream() is the only reliable audio-track probe in Chromium for local
 * files; audioTracks is unavailable there. The tracks are stopped immediately.
 *
 * @returns {Promise<{duration: number, width: number, height: number, hasVideo: boolean, hasAudio: boolean}>}
 */
export function readMediaMetadata(file) {
  return new Promise((resolve, reject) => {
    const kind = fileKind(file);
    const media = document.createElement(kind === "audio" ? "audio" : "video");
    const url = URL.createObjectURL(file);
    let settled = false;
    let timer = null;
    let seekTimer = null;

    const cleanup = () => {
      clearTimeout(timer);
      clearTimeout(seekTimer);
      media.removeEventListener("loadedmetadata", onMetadata);
      media.removeEventListener("durationchange", onDurationChange);
      media.removeEventListener("timeupdate", onDurationChange);
      media.removeEventListener("error", onError);
      media.removeAttribute("src");
      try {
        media.load();
      } catch {
        /* the element is already detached */
      }
      URL.revokeObjectURL(url);
    };

    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      if (error) reject(error);
      else resolve(value);
    };

    const settle = () => {
      const duration = Number(media.duration);
      if (!Number.isFinite(duration) || duration <= 0) return false;

      let stream = null;
      try {
        stream = typeof media.captureStream === "function" ? media.captureStream() : null;
      } catch {
        stream = null;
      }
      const hasAudio = stream
        ? stream.getAudioTracks().length > 0
        : media.audioTracks
          ? media.audioTracks.length > 0
          : kind === "audio";
      const hasVideo = stream
        ? stream.getVideoTracks().length > 0
        : media.videoWidth > 0 && media.videoHeight > 0;
      if (stream) stream.getTracks().forEach((track) => track.stop());

      finish(null, {
        duration,
        width: media.videoWidth || 0,
        height: media.videoHeight || 0,
        hasVideo: kind === "audio" ? false : hasVideo,
        hasAudio,
      });
      return true;
    };

    function onMetadata() {
      if (settle()) return;
      // A WebM recorded without a duration reports Infinity until the browser
      // is asked to seek; this is the standard way to make it reveal the length.
      try {
        media.currentTime = 1e7;
      } catch {
        finish(new Error("This file's duration could not be read."));
        return;
      }
      seekTimer = setTimeout(
        () => finish(new Error("This file's duration could not be read.")),
        5000
      );
    }

    function onDurationChange() {
      if (!settled) settle();
    }

    function onError() {
      finish(new Error("This file could not be previewed. Trim and merge need a readable duration."));
    }

    timer = setTimeout(
      () => finish(new Error("This file took too long to read. Try a smaller file.")),
      20_000
    );
    media.preload = "metadata";
    media.muted = true;
    media.playsInline = true;
    media.addEventListener("loadedmetadata", onMetadata, { once: true });
    media.addEventListener("durationchange", onDurationChange);
    media.addEventListener("timeupdate", onDurationChange);
    media.addEventListener("error", onError, { once: true });
    media.src = url;
    media.load();
  });
}

function extensionOf(name) {
  return String(name || "").split(".").pop().toLowerCase();
}
