// Turns the popup's choices into an ffmpeg argument list. Pure: no DOM and no
// browser APIs, so node --test imports it directly and the worker uses the
// exact same planning code the UI was tested against.

export const LOCAL_FORMATS = ["mp4", "webm", "mp3", "m4a"];

const AUDIO_BITRATE = { high: "192k", balanced: "160k", small: "128k" };

// CRF is a quality target, not a size target, so the encoder is free to spend
// bits where they matter. The wasm build is slow, so video uses ultrafast.
const VIDEO_CRF = {
  mp4: { high: 20, balanced: 25, small: 31 },
  webm: { high: 14, balanced: 24, small: 34 },
};

export const MIME = {
  mp4: "video/mp4",
  webm: "video/webm",
  mp3: "audio/mpeg",
  m4a: "audio/mp4",
};

/** Encoder arguments shared by single-file conversion and clip merges. */
export function codecArgs(format, quality = "balanced") {
  if (!LOCAL_FORMATS.includes(format)) throw new Error(`Unsupported output format: ${format}`);
  if (!AUDIO_BITRATE[quality]) throw new Error(`Unsupported quality: ${quality}`);

  const audio = AUDIO_BITRATE[quality];
  if (format === "mp3") {
    return ["-vn", "-c:a", "libmp3lame", "-b:a", audio];
  }
  if (format === "m4a") {
    return ["-vn", "-c:a", "aac", "-b:a", audio, "-movflags", "+faststart"];
  }
  if (format === "mp4") {
    return [
      "-c:v", "libx264",
      "-preset", "ultrafast",
      "-crf", String(VIDEO_CRF.mp4[quality]),
      "-pix_fmt", "yuv420p",
      "-c:a", "aac",
      "-b:a", audio,
      "-movflags", "+faststart",
    ];
  }
  return [
    "-c:v", "libvpx",
    "-b:v", "0",
    "-crf", String(VIDEO_CRF.webm[quality]),
    "-c:a", "libvorbis",
    "-b:a", audio,
  ];
}

function seconds(value) {
  return String(Math.round(value * 1000) / 1000);
}

/** "90", "1:30" and "1:02:03.5" all mean a time in seconds. */
export function parseTimeInput(raw) {
  const value = String(raw ?? "").trim();
  if (!value) return null;
  if (/^\d+(?:\.\d+)?$/.test(value)) return Number(value);

  const parts = value.split(":");
  if (parts.length < 2 || parts.length > 3) return NaN;
  if (!/^\d+$/.test(parts[0])) return NaN;
  if (parts.length === 2) {
    if (!/^\d+(?:\.\d+)?$/.test(parts[1])) return NaN;
  } else if (!/^\d+$/.test(parts[1]) || !/^\d+(?:\.\d+)?$/.test(parts[2])) {
    return NaN;
  }

  const numbers = parts.map(Number);
  if (numbers.slice(1).some((part) => part >= 60)) return NaN;
  if (parts.length === 2) return numbers[0] * 60 + numbers[1];
  return numbers[0] * 3600 + numbers[1] * 60 + numbers[2];
}

function trimValue(value) {
  // null, undefined and "" all mean "field left empty", which must not turn
  // into 0 — Number(null) is 0 and would ask ffmpeg for a zero-length clip.
  if (value === null || value === undefined || value === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : NaN;
}

/** Resolves the trim fields into a seek point and a duration. */
export function normalizeTrim(start = null, end = null) {
  const from = trimValue(start);
  const to = trimValue(end);

  if (Number.isNaN(from) || Number.isNaN(to)) {
    throw new Error("Use seconds or m:ss for the trim times.");
  }

  const hasStart = from !== null && from > 0;
  const hasEnd = to !== null;

  if (hasStart && hasEnd && to <= from) {
    throw new Error("The end time has to be after the start time.");
  }
  if (!hasStart && hasEnd && to <= 0) {
    throw new Error("The end time has to be after the start time.");
  }
  if (hasStart && hasEnd) return { start: from, duration: to - from };
  if (hasStart) return { start: from, duration: null };
  if (hasEnd) return { start: null, duration: to };
  return { start: null, duration: null };
}

/**
 * @returns {{args: string[], output: string, mime: string, expectedDuration: number|null}}
 */
export function planConversion({
  format,
  quality = "balanced",
  start = null,
  end = null,
  input = "input.media",
} = {}) {
  if (!LOCAL_FORMATS.includes(format)) throw new Error(`Unsupported output format: ${format}`);
  if (!AUDIO_BITRATE[quality]) throw new Error(`Unsupported quality: ${quality}`);

  const trim = normalizeTrim(start, end);
  const output = `output.${format}`;
  const args = [];

  // Seeking before the input is much faster than decoding from the start.
  if (trim.start !== null) args.push("-ss", seconds(trim.start));
  args.push("-i", input);
  if (trim.duration !== null) args.push("-t", seconds(trim.duration));

  args.push(...codecArgs(format, quality), output);
  return { args, output, mime: MIME[format], expectedDuration: trim.duration };
}

/** "holiday clip.mov" + "mp3" -> "holiday clip.mp3", with no path or control bytes. */
export function outputName(original, format) {
  const tail = String(original || "").split(/[\\/]/).pop() || "";
  const base = tail
    .replace(/\.[^.]+$/, "")
    .replace(/[\u0000-\u001f<>:"|?*]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);
  return `${base || "hopper"}.${LOCAL_FORMATS.includes(format) ? format : "mp4"}`;
}
