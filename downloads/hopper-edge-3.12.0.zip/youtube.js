// Pure video helpers for the Video tab: YouTube's offline fallback parser,
// format grouping and the labels the rows show. No chrome.* and no fetch, so
// Node tests this directly.
//
// The companion already normalizes yt-dlp's output into rows of
//   { formatId, kind, label, container, height, fps, bitrateKbps, codecs,
//     sizeBytes, sizeLabel, note, merged }
// and sorts them combined -> video -> audio. This module only groups them.

const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;
const HOSTS = new Set(["youtube.com", "music.youtube.com", "youtube-nocookie.com", "youtu.be"]);

/** Accepts a full URL, a share URL, a shorts link or a bare 11-character id. */
export function videoIdFromInput(raw) {
  const value = String(raw ?? "").trim();
  if (!value) return null;
  if (VIDEO_ID_RE.test(value)) return value;

  // A pasted link without a scheme ("youtu.be/xyz") is the common case.
  const candidate = /^[a-z]+:\/\//i.test(value) ? value : `https://${value}`;
  let url;
  try {
    url = new URL(candidate);
  } catch {
    return null;
  }

  const host = url.hostname.replace(/^www\./, "").replace(/^m\./, "");
  if (!HOSTS.has(host)) return null;

  const id =
    host === "youtu.be"
      ? url.pathname.slice(1).split("/")[0]
      : url.searchParams.get("v") ||
        (url.pathname.match(/^\/(?:embed|v|shorts|live)\/([^/?#]+)/) || [])[1] ||
        "";

  return VIDEO_ID_RE.test(id.trim()) ? id.trim() : null;
}

export function watchUrl(id) {
  return `https://www.youtube.com/watch?v=${id}`;
}

/** "12:04" or "1:02:33" — duration as a person reads it. */
export function durationLabel(seconds) {
  const total = Math.max(0, Math.round(Number(seconds) || 0));
  if (!total) return "";
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const pad = (value) => String(value).padStart(2, "0");
  return hours ? `${hours}:${pad(minutes)}:${pad(secs)}` : `${minutes}:${pad(secs)}`;
}

/** Split the companion's sorted list into the three groups the tab shows. */
export function groupFormats(formats) {
  const list = Array.isArray(formats) ? formats.filter((row) => row && row.formatId) : [];
  const groups = {
    combined: list.filter((row) => row.kind === "combined"),
    video: list.filter((row) => row.kind === "video"),
    audio: list.filter((row) => row.kind === "audio"),
    counts: {
      combined: 0,
      video: 0,
      audio: 0,
    },
    total: list.length,
  };
  groups.counts = {
    combined: groups.combined.length,
    video: groups.video.length,
    audio: groups.audio.length,
  };
  return groups;
}

export function bestAudio(groups) {
  return (groups && groups.audio && groups.audio[0]) || null;
}

/**
 * What the primary button downloads.
 *
 * "With sound" rows are one file, so they win. Without one, high resolutions
 * only exist as separate video and audio streams, so the pair is the honest
 * answer — but only when ffmpeg can merge them.
 */
export function recommendedPicks(groups, { hasFfmpeg = false } = {}) {
  if (!groups) return [];
  if (groups.combined.length) return [groups.combined[0].formatId];
  if (groups.video.length) {
    const picks = [groups.video[0].formatId];
    const audio = hasFfmpeg ? bestAudio(groups) : null;
    if (audio) picks.push(audio.formatId);
    return picks;
  }
  if (groups.audio.length) return [groups.audio[0].formatId];
  return [];
}

/** The three things the picker offers, in the order it shows them. */
export const PICK_MODES = ["combined", "video", "audio"];

/** The rows the picker lists for a mode; empty when the site offered none. */
export function rowsForMode(groups, mode) {
  if (!groups) return [];
  if (mode === "video") return groups.video || [];
  if (mode === "audio") return groups.audio || [];
  return groups.combined || [];
}

/** The mode a video opens in: merged when possible, whatever else exists after. */
export function defaultMode(groups) {
  for (const mode of PICK_MODES) {
    if (rowsForMode(groups, mode).length) return mode;
  }
  return "combined";
}

/**
 * What the primary button downloads for a mode: the best row, as one format id.
 * Combined rows already carry the audio (``299+140``), so no pairing happens
 * here; when the site offers no merged row at all, the best video is paired
 * with the best audio as a fallback.
 */
export function picksForMode(groups, mode, { hasFfmpeg = false } = {}) {
  const rows = rowsForMode(groups, mode);
  if (rows.length) return [rows[0].formatId];
  if (mode === "combined" && groups && groups.video && groups.video.length) {
    const picks = [groups.video[0].formatId];
    const audio = hasFfmpeg ? bestAudio(groups) : null;
    if (audio) picks.push(audio.formatId);
    return picks;
  }
  return [];
}

/** Human name for a codec string like "avc1.640028,mp4a.40.2". */
export function codecSummary(format) {
  const raw = String(format?.codecs || "").toLowerCase();
  const names = [];
  if (/avc1|h264/.test(raw)) names.push("H.264");
  else if (/hvc1|hevc|h265/.test(raw)) names.push("HEVC");
  else if (/vp0?9|vp09/.test(raw)) names.push("VP9");
  else if (/av01/.test(raw)) names.push("AV1");
  if (/mp4a|aac/.test(raw)) names.push("AAC");
  else if (/opus/.test(raw)) names.push("Opus");
  else if (/vorbis/.test(raw)) names.push("Vorbis");
  return names.join(" + ");
}

/** Second line of a format row: container, codecs, bitrate, size. */
export function rowDetail(format) {
  const bits = [];
  if (format?.container) bits.push(String(format.container).toUpperCase());
  const codecs = codecSummary(format);
  if (codecs) bits.push(codecs);
  else if (format?.kind === "video") bits.push("no audio");
  // Audio bitrate is the actual pick for sound-only rows (e.g. 128 vs 160
  // vs 256 kbps), so it is always shown when the companion reports it.
  if (Number.isFinite(Number(format?.bitrateKbps)) && Number(format.bitrateKbps) > 0) {
    bits.push(`${Math.round(Number(format.bitrateKbps))} kbps`);
  }
  if (format?.sizeLabel) bits.push(format.sizeLabel);
  return bits.join(" · ");
}

/** Why /info refused, in words that tell the user what to do next. */
export function infoMessage(reason, fallback) {
  const messages = {
    live: "This is a live stream, so there is no finished file to save.",
    "no-formats": "No downloadable format was offered for this video.",
    "not-video": "That link doesn't point at a video.",
    age: "This video is age-restricted and can't be downloaded without cookies.",
    private: "This video is private or members-only.",
    unavailable: "This video is unavailable.",
  };
  return messages[reason] || fallback || "No downloadable format was returned for this video.";
}

/** Banner under the format list, when there is something worth knowing. */
export function videoNote(info) {
  if (!info) return "";
  if (info.live) return "Live stream: formats appear once the broadcast ends.";
  if (info.hasFfmpeg === false) {
    return "ffmpeg wasn't found, so high resolutions and merged audio aren't available.";
  }
  return "";
}
