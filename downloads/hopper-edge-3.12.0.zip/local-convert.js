// Popup-side handle for the wasm converter. One job at a time: the worker is
// created per job and terminated to cancel, because ffmpeg runs synchronously
// inside wasm and cannot be interrupted politely.

const WORKER_URL = "convert-worker.js";
const START_TIMEOUT_MS = 90_000;
const JOB_TIMEOUT_MS = 25 * 60 * 1000;

export class LocalConverter {
  #worker = null;
  #finish = null;
  #timer = null;
  #cancelMessage = "The job was canceled.";
  // Cancel can land while the files are still being read into memory. That is
  // before #start() exists, so a worker-only cancel would miss it and the job
  // would start after the popup already looked idle. The generation makes a
  // canceled preparation refuse to become a worker.
  #generation = 0;

  get busy() {
    return this.#worker !== null;
  }

  /**
   * @param {object} input
   * @param {File} input.file
   * @param {string} input.format
   * @param {string} input.quality
   * @param {number|null} input.start
   * @param {number|null} input.end
   * @param {(percent: number|null) => void} [input.onProgress]
   * @returns {Promise<{blob: Blob, format: string}>}
   */
  async convert({ file, format, quality, start, end, onProgress }) {
    if (this.busy) throw new Error("A job is already running.");
    const generation = this.#generation;
    const buffer = await file.arrayBuffer();
    if (generation !== this.#generation) throw new Error("The conversion was canceled.");

    return this.#start(
      {
        type: "run",
        kind: "convert",
        buffer,
        input: `input${extensionFor(file.name)}`,
        format,
        quality,
        start,
        end,
      },
      [buffer],
      onProgress,
      "The conversion was canceled.",
      generation
    );
  }

  /**
   * @param {object} input
   * @param {Array<{file: File, start: number|null, end: number|null, duration: number, width: number, height: number, hasVideo: boolean, hasAudio: boolean}>} input.clips
   * @param {string} input.format
   * @param {string} input.quality
   * @param {(percent: number|null) => void} [input.onProgress]
   * @returns {Promise<{blob: Blob, format: string}>}
   */
  async merge({ clips, format, quality, onProgress }) {
    if (this.busy) throw new Error("A job is already running.");
    const generation = this.#generation;

    // Every input goes to the worker at once. A merge is one pass, so there is
    // no intermediate file to re-encode or lose quality between clips.
    const prepared = await Promise.all(
      clips.map(async (clip, index) => ({
        input: `source${index}${extensionFor(clip.file.name)}`,
        buffer: await clip.file.arrayBuffer(),
        start: clip.start,
        end: clip.end,
        duration: clip.duration,
        width: clip.width,
        height: clip.height,
        hasVideo: clip.hasVideo,
        hasAudio: clip.hasAudio,
      }))
    );
    if (generation !== this.#generation) throw new Error("The merge was canceled.");

    return this.#start(
      { type: "run", kind: "merge", clips: prepared, format, quality },
      prepared.map((clip) => clip.buffer),
      onProgress,
      "The merge was canceled.",
      generation
    );
  }

  #start(message, transfer, onProgress, cancelMessage, generation) {
    if (this.busy) throw new Error("A job is already running.");
    if (generation !== this.#generation) throw new Error(cancelMessage);
    this.#cancelMessage = cancelMessage;

    return new Promise((resolve, reject) => {
      const worker = new Worker(WORKER_URL, { type: "module" });
      this.#worker = worker;

      const settle = (error, value) => {
        if (!this.#finish) return;
        this.#finish = null;
        this.#stop();
        if (error) reject(error);
        else resolve(value);
      };

      this.#finish = settle;

      const arm = (ms, text) => {
        clearTimeout(this.#timer);
        this.#timer = setTimeout(() => settle(new Error(text)), ms);
      };
      arm(START_TIMEOUT_MS, "The converter took too long to start.");

      worker.addEventListener("message", (event) => {
        const reply = event.data;
        if (!reply) return;
        if (reply.type === "progress") {
          if (typeof onProgress === "function") onProgress(reply.percent);
          return;
        }
        if (reply.type === "done") {
          const blob = new Blob([reply.buffer], { type: reply.mime || "application/octet-stream" });
          settle(null, { blob, format: message.format });
          return;
        }
        if (reply.type === "error") {
          settle(new Error(reply.message || "The job failed."));
        }
      });

      worker.addEventListener("error", (event) => {
        settle(new Error(event.message || "The converter could not be started."));
      });

      worker.postMessage({ ...message, id: Date.now() }, transfer);
      arm(JOB_TIMEOUT_MS, "The job timed out. Try shorter clips or smaller files.");
      if (typeof onProgress === "function") onProgress(null);
    });
  }

  cancel() {
    this.#generation += 1;
    if (this.#finish) this.#finish(new Error(this.#cancelMessage));
    this.#stop();
  }

  #stop() {
    clearTimeout(this.#timer);
    this.#timer = null;
    const worker = this.#worker;
    this.#worker = null;
    if (worker) worker.terminate();
  }
}

function extensionFor(name) {
  const match = /\.[a-z0-9]{1,5}$/i.exec(String(name || ""));
  return match ? match[0].toLowerCase() : ".media";
}
