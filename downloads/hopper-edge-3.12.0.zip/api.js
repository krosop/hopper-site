// Companion HTTP client and the shared request helpers.
//
// Everything Hopper cannot do inside a tab happens behind this module: yt-dlp
// extraction, native ffmpeg, and the prepared-file stream. The companion is
// bound to loopback and the manifest only allows 127.0.0.1.

export const COMPANION_BASE = "http://127.0.0.1:8765";

export function timeoutSignal(ms) {
  return typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"
    ? AbortSignal.timeout(ms)
    : undefined;
}

/**
 * Keep raw companion and downloader text out of the UI. Errors can quote the
 * source site or the extractor by name; the popup only needs the next step.
 */
export function publicMessage(value) {
  return String(value ?? "")
    .replace(/https?:\/\/(?:[a-z0-9-]+\.)*youtube(?:-nocookie)?\.com\/\S*/gi, "the video page")
    .replace(/https?:\/\/youtu\.be\/\S*/gi, "the video page")
    .replace(/https?:\/\/(?:[a-z0-9-]+\.)*tiktok\.com\/\S*/gi, "the video page")
    .replace(/\byoutube(?:-nocookie)?\b/gi, "the site")
    .replace(/\btiktok\b/gi, "the site")
    .replace(/\byt-dlp\b/gi, "the companion");
}

/** Turn a fetch/abort failure into a sentence a person can act on. */
export function networkMessage(error) {
  const message = String((error && error.message) || error || "");
  if (/failed to fetch|networkerror|load failed|fetch failed|connection refused/i.test(message)) {
    return "The companion isn't reachable. Start it, then check the status pill.";
  }
  if (/aborted|aborterror/i.test(message)) {
    return "The request was canceled.";
  }
  return publicMessage(message) || "Something went wrong.";
}

/** Read the companion's own explanation instead of inventing one. */
export async function apiErrorText(response) {
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  const message = publicMessage(body && (body.error || body.message));
  if (response.status === 413) return "That file is too large. The limit is 2 GB.";
  if (response.status === 404) return message || "That job is gone. Try again.";
  if (response.status === 409) return message || "That job is already running. Wait for it to finish.";
  if (response.status === 503) return message || "The companion needs ffmpeg for this job.";
  return message || `The companion returned HTTP ${response.status}.`;
}

/** chrome.downloads' interruption reasons, in words a person can act on. */
export function downloadFailure(code) {
  const messages = {
    USER_CANCELED: "The download was canceled.",
    NETWORK_FAILED: "The browser couldn't receive the file. Check the companion log.",
    FILE_NO_SPACE: "There isn't enough disk space for this file.",
    FILE_ACCESS_DENIED: "Windows blocked the save location.",
    FILE_NAME_TOO_LONG: "That filename is too long. Try a shorter source name.",
    SERVER_BAD_CONTENT: "The companion sent an unreadable file.",
  };
  return messages[code] || `The browser stopped the download${code ? ` (${code})` : ""}.`;
}

export class Companion {
  #base;

  constructor(base = COMPANION_BASE) {
    this.#base = String(base || COMPANION_BASE).replace(/\/+$/, "");
  }

  get base() {
    return this.#base;
  }

  async request(pathname, { method = "GET", body, headers, timeout = 15_000 } = {}) {
    const response = await fetch(`${this.#base}${pathname}`, {
      method,
      headers,
      body,
      cache: "no-store",
      signal: timeoutSignal(timeout),
    });
    if (!response.ok) throw new Error(await apiErrorText(response));
    return response.json();
  }

  health() {
    return this.request("/health", { timeout: 2500 });
  }

  /** Fast and offline: the companion's registry canonicalises the link. */
  detect(url) {
    return this.request("/detect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      timeout: 5000,
    });
  }

  /** Slow on the first call: yt-dlp has to extract the page. */
  info(url) {
    return this.request("/info", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      timeout: 120_000,
    });
  }

  prepare({ url, formatId, filename, title, subs = false }) {
    return this.request("/prepare", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, formatId, filename, title, subs }),
      timeout: 30_000,
    });
  }

  job(jobId) {
    return this.request(`/job/${encodeURIComponent(jobId)}`, { timeout: 8000 });
  }

  /** Cancellation is idempotent, so a missing job is not an error. */
  cancel(jobId) {
    return this.request(`/job/${encodeURIComponent(jobId)}`, {
      method: "DELETE",
      timeout: 5000,
    }).catch(() => null);
  }
}
