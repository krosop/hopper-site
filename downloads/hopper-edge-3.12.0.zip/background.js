// Announces the extension to the local companion.
//
// The hub's setup screen needs to know that the user's "Load unpacked" click
// actually produced a working extension, and Chrome offers no way to ask that
// from outside the browser. So the service worker says hello when the extension
// is installed and on every browser start; the companion remembers the ping and
// /health reports it back as `extension: { version, connected }`.

const HEALTH = "http://127.0.0.1:8765/health";

async function announce() {
  try {
    const version = chrome.runtime.getManifest().version;
    await fetch(`${HEALTH}?ext=${encodeURIComponent(version)}`, { cache: "no-store" });
  } catch {
    // The companion may not be running yet. The next browser start retries, and
    // opening the popup also reaches /health.
  }
}

chrome.runtime.onInstalled.addListener(() => void announce());
chrome.runtime.onStartup.addListener(() => void announce());
void announce();
