// The download core behind the Video tab.
//
// One "pick" is one yt-dlp job: a single format id, or a video+audio pair that
// only exists as a pair. The same flow runs for every pick:
//
//   prepare -> wait until bytes exist -> hand the browser a /stream URL
//           -> wait for chrome.downloads to finish
//
// Nothing reaches chrome.downloads until the companion reports `ready`, so a
// failed extraction can never be saved as a file full of JSON.

import { downloadFailure } from "./api.js";

export class VideoDownloader {
  #slots = [];
  #canceled = false;
  #update = null;

  constructor({ companion, downloads, pollMs = 500, wait, timeoutMs = 30 * 60_000, maxPolls = 4000 } = {}) {
    if (!companion) throw new Error("VideoDownloader needs a companion client.");
    if (!downloads) throw new Error("VideoDownloader needs the download wrappers.");
    this.companion = companion;
    this.downloads = downloads;
    this.pollMs = pollMs;
    this.wait = typeof wait === "function" ? wait : (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    this.timeoutMs = timeoutMs;
    this.maxPolls = maxPolls;
  }

  get busy() {
    return this.#slots.length > 0;
  }

  get canceled() {
    return this.#canceled;
  }

  /**
   * @param {object} input
   * @param {string} input.url       canonical watch URL
   * @param {string} [input.title]   used for the fallback filename
   * @param {string[]} input.picks   format ids, one job each
   * @param {(state: {phase: "preparing"|"saving"|"done", percent: number|null, downloadIds: number[]}) => void} [input.onUpdate]
   */
  async start({ url, title, picks, subs = false, onUpdate }) {
    if (this.busy) throw new Error("A download is already running.");
    const formatIds = Array.isArray(picks) ? picks.filter(Boolean) : [];
    if (!formatIds.length) throw new Error("Pick a format first.");
    this.subs = subs === true;
    this.subsJobs = [];

    this.#canceled = false;
    this.#update = typeof onUpdate === "function" ? onUpdate : () => {};
    this.#slots = formatIds.map((formatId) => ({
      formatId,
      jobId: null,
      filename: "",
      percent: null,
      downloadId: null,
    }));
    this.#emit("preparing", null);

    const deadline = Date.now() + this.timeoutMs;
    try {
      // All picks prepare and become ready before any of them reaches the
      // browser, so a pair is either two finished downloads or none: a failed
      // half never leaves a silent video file in the Downloads folder.
      await Promise.all(this.#slots.map((slot) => this.#prepare(slot, { url, title })));
      if (this.#canceled) return;
      await Promise.all(this.#slots.map((slot) => this.#waitReady(slot, deadline)));
      if (this.#canceled) return;
      // Sidecars first: the companion releases a finished job the moment its
      // media download ends, so the .srt has to be on disk before that.
      await this.#streamSubs();
      if (this.#canceled) return;
      await Promise.all(this.#slots.map((slot) => this.#stream(slot)));
      if (this.#canceled) return;
      this.#emit("done", 100);
    } catch (error) {
      // A cancel interrupts whatever was in flight; that is not a failure.
      if (this.#canceled) return;
      await this.#release();
      throw error;
    } finally {
      if (!this.#canceled) {
        this.#slots = [];
        this.#update = null;
      }
    }
  }

  async cancel() {
    this.#canceled = true;
    await this.#release();
    this.#slots = [];
    this.#update = null;
  }

  // -------------------------------------------------------------------------

  async #prepare(slot, { url, title }) {
    const data = await this.companion.prepare({ url, formatId: slot.formatId, title, subs: this.subs });
    if (!data || data.ok !== true || !data.jobId) {
      throw new Error((data && data.error) || "The companion couldn't start this download.");
    }
    slot.jobId = data.jobId;
    slot.filename = data.filename || "";
  }

  async #waitReady(slot, deadline) {
    let polls = 0;

    for (;;) {
      if (this.#canceled) return;
      if (polls++ > this.maxPolls || Date.now() > deadline) {
        throw new Error("The download took too long. Try again, or pick a smaller format.");
      }

      const job = await this.companion.job(slot.jobId);
      if (!job || job.ok === false) {
        throw new Error((job && job.error) || "The companion lost that download.");
      }
      if (job.state === "error" || job.state === "canceled") {
        if (this.#canceled) return;
        throw new Error(job.error || "The download failed.");
      }
      if (job.state === "ready") {
        slot.filename = job.filename || slot.filename;
        if (job.hasSubs && job.subsFilename) {
          this.subsJobs.push({ jobId: slot.jobId, filename: job.subsFilename });
        }
        return;
      }

      slot.percent = Number.isFinite(job.percent) ? Math.min(99, Math.round(job.percent)) : null;
      this.#emit("preparing", this.#aggregate());
      await this.wait(this.pollMs);
    }
  }

  async #stream(slot) {
    if (this.#canceled) return;

    let polls = 0;
    slot.downloadId = await this.downloads.start({
      url: `${this.companion.base}/stream?job=${encodeURIComponent(slot.jobId)}`,
      filename: slot.filename,
      saveAs: false,
      conflictAction: "uniquify",
    });
    this.#emit("saving", this.#aggregate());

    for (;;) {
      if (this.#canceled) return;
      if (polls++ > this.maxPolls * 4) {
        throw new Error("The browser stopped reporting this download.");
      }

      const items = await this.downloads.search(slot.downloadId);
      const item = Array.isArray(items) ? items[0] : null;
      if (!item) throw new Error("The browser lost that download.");

      if (item.state === "complete") {
        slot.percent = 100;
        this.#emit("saving", this.#aggregate());
        return;
      }
      if (item.state === "interrupted") {
        if (this.#canceled) return;
        throw new Error(downloadFailure(item.error));
      }

      const total = Number(item.totalBytes) || 0;
      const received = Number(item.bytesReceived) || 0;
      slot.percent = total > 0 ? Math.min(99, Math.round((received / total) * 100)) : null;
      this.#emit("saving", this.#aggregate());
      await this.wait(this.pollMs);
    }
  }

  async #streamSubs() {
    if (!this.subs || !this.subsJobs.length) return;
    const sidecars = this.subsJobs;
    this.subsJobs = [];

    for (const sidecar of sidecars) {
      if (this.#canceled) return;

      let downloadId;
      try {
        downloadId = await this.downloads.start({
          url: `${this.companion.base}/subs?job=${encodeURIComponent(sidecar.jobId)}`,
          filename: sidecar.filename,
          saveAs: false,
          conflictAction: "uniquify",
        });
      } catch {
        // A sidecar is a bonus: a missing subtitle never fails the video.
        continue;
      }

      // A few kilobytes, so wait it out instead of racing the job cleanup.
      for (let polls = 0; polls < 40; polls += 1) {
        if (this.#canceled) {
          try {
            await this.downloads.cancel(downloadId);
          } catch {
            /* it may already be gone */
          }
          return;
        }

        let items = [];
        try {
          items = await this.downloads.search(downloadId);
        } catch {
          break;
        }
        const item = Array.isArray(items) ? items[0] : null;
        if (!item || item.state === "complete" || item.state === "interrupted") break;
        await this.wait(250);
      }
    }
  }

  async #release() {
    const slots = this.#slots;
    await Promise.all(
      slots.map(async (slot) => {
        if (slot.downloadId !== null) {
          try {
            await this.downloads.cancel(slot.downloadId);
          } catch {
            /* it may already be gone */
          }
        }
        if (slot.jobId) await this.companion.cancel(slot.jobId);
      })
    );
  }

  #aggregate() {
    const slots = this.#slots;
    if (!slots.length) return null;
    if (slots.some((slot) => !Number.isFinite(slot.percent))) return null;
    const total = slots.reduce((sum, slot) => sum + slot.percent, 0);
    return Math.min(99, Math.round(total / slots.length));
  }

  #downloadIds() {
    return this.#slots
      .map((slot) => slot.downloadId)
      .filter((id) => Number.isFinite(id) && id > 0);
  }

  #emit(phase, percent) {
    if (typeof this.#update !== "function") return;
    // The ids let the Video tab reconcile a row after the popup is closed and
    // reopened: a finished browser download is marked done, not downloaded
    // again.
    this.#update({ phase, percent, downloadIds: this.#downloadIds() });
  }
}
