// Plans one ffmpeg pass that joins several clips. The browser pipeline already
// converts each clip with ffmpeg.wasm, so a merge is the same encoder with a
// filter graph: every clip is scaled into one frame, padded instead of cropped,
// given a stereo track (silence when it has none), trimmed, then concatenated.
//
// Pure on purpose: node --test imports this module directly.

import { codecArgs, LOCAL_FORMATS, MIME } from "./convert-plan.js";

const AUDIO_FORMATS = new Set(["mp3", "m4a"]);
const MIN_SEGMENT = 0.05;

function seconds(value) {
  return String(Math.round(value * 1000) / 1000);
}

/** Why this clip's trim cannot be used, or "" when it is fine. */
export function clipProblem(clip) {
  const duration = Number(clip && clip.duration);
  if (!Number.isFinite(duration) || duration <= 0) return "This clip needs a readable duration.";

  const rawStart = clip.start === null || clip.start === undefined ? 0 : Number(clip.start);
  const rawEnd = clip.end === null || clip.end === undefined ? duration : Number(clip.end);
  if (!Number.isFinite(rawStart) || !Number.isFinite(rawEnd)) {
    return "Use seconds or m:ss for the trim times.";
  }
  if (rawStart < 0 || rawEnd < 0) return "Time can't be negative.";
  if (rawStart >= duration) return "Start has to be before the clip ends.";
  if (rawEnd <= rawStart) return "End has to be after start.";

  const start = Math.min(rawStart, duration);
  const end = Math.min(rawEnd, duration);
  if (end - start < MIN_SEGMENT) return "Keep at least a moment of the clip.";
  return "";
}

/** The kept part of a clip, clamped to the duration the browser decoded. */
export function clipSegment(clip) {
  if (clipProblem(clip)) return null;
  const duration = Number(clip.duration);
  const rawStart = clip.start === null || clip.start === undefined ? 0 : Number(clip.start);
  const rawEnd = clip.end === null || clip.end === undefined ? duration : Number(clip.end);
  const start = Math.min(Math.max(rawStart, 0), duration);
  const end = Math.min(Math.max(rawEnd, 0), duration);
  return { start, duration: end - start };
}

/**
 * Why these clips cannot be merged into this format, or null when they can.
 * The same message is shown by the popup and thrown by the planner, so the
 * button and the worker can never disagree about compatibility.
 */
export function mergeProblem(clips, format) {
  if (!LOCAL_FORMATS.includes(format)) return `Unsupported output format: ${format}`;
  if (!Array.isArray(clips) || clips.length < 2) return "Add at least two clips to merge.";

  const audioOnly = AUDIO_FORMATS.has(format);

  for (let index = 0; index < clips.length; index += 1) {
    const clip = clips[index];
    const label = `Clip ${index + 1}`;
    if (!clip || !clipSegment(clip)) return `${label}: ${clipProblem(clip) || "has no playable duration."}`;
    if (!audioOnly && !clip.hasVideo) return `${label} is audio only. Choose MP3 or M4A to merge audio.`;
    if (audioOnly && !clip.hasAudio) return `${label} has no audio track.`;
    if (!audioOnly && (!(clip.width > 0) || !(clip.height > 0))) {
      return `${label} has no video frame size.`;
    }
  }

  return null;
}

/**
 * @returns {{
 *   args: string[],
 *   output: string,
 *   mime: string,
 *   expectedDuration: number
 * }}
 */
export function planMerge({ format, quality = "balanced", clips = [], output = "studio" } = {}) {
  const problem = mergeProblem(clips, format);
  if (problem) throw new Error(problem);

  const audioOnly = AUDIO_FORMATS.has(format);
  const width = Math.max(2, Math.round(Number(clips[0].width) / 2) * 2);
  const height = Math.max(2, Math.round(Number(clips[0].height) / 2) * 2);
  const args = [];
  const filters = [];
  const videoLabels = [];
  const audioLabels = [];
  let inputs = 0;
  let duration = 0;

  for (let index = 0; index < clips.length; index += 1) {
    const clip = clips[index];
    const segment = clipSegment(clip);
    duration += segment.duration;

    // Input-side trim: seeking first keeps long sources from being decoded in
    // full, and -t bounds each input to exactly what survives.
    if (segment.start > 0) args.push("-ss", seconds(segment.start));
    args.push("-t", seconds(segment.duration), "-i", clip.input);
    const input = inputs;
    inputs += 1;

    if (!audioOnly) {
      filters.push(
        `[${input}:v]scale=${width}:${height}:force_original_aspect_ratio=decrease,` +
          `pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps=30,` +
          `setpts=PTS-STARTPTS[v${index}]`
      );
      videoLabels.push(`[v${index}]`);
    }

    if (clip.hasAudio) {
      filters.push(
        `[${input}:a]aresample=48000,` +
          `aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo,` +
          `apad=whole_dur=${seconds(segment.duration)},` +
          `atrim=duration=${seconds(segment.duration)},asetpts=PTS-STARTPTS[a${index}]`
      );
    } else if (!audioOnly) {
      // A silent video still needs an audio stream to concat, so this clip gets
      // its own generated silence of the same length.
      args.push(
        "-f", "lavfi",
        "-t", seconds(segment.duration),
        "-i", "anullsrc=channel_layout=stereo:sample_rate=48000"
      );
      filters.push(
        `[${inputs}:a]atrim=duration=${seconds(segment.duration)},` +
          `asetpts=PTS-STARTPTS[a${index}]`
      );
      inputs += 1;
    }
    audioLabels.push(`[a${index}]`);
  }

  if (audioOnly) {
    filters.push(`${audioLabels.join("")}concat=n=${clips.length}:v=0:a=1[out]`);
  } else {
    const pairs = videoLabels.map((video, index) => video + audioLabels[index]);
    filters.push(`${pairs.join("")}concat=n=${clips.length}:v=1:a=1[vout][aout]`);
  }

  args.push("-filter_complex", filters.join(";"));
  args.push(...(audioOnly ? ["-map", "[out]"] : ["-map", "[vout]", "-map", "[aout]"]));
  args.push(...codecArgs(format, quality), `${output}.${format}`);

  return {
    args,
    output: `${output}.${format}`,
    mime: MIME[format],
    expectedDuration: duration,
  };
}
