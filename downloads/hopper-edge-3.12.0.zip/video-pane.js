// The Video tab: read the open YouTube tab (or a pasted link), show the
// formats the companion found, and hand a chosen format to the downloader.
//
// The popup downloads the video that is open. There is no queue or playlist
// panel: a watch link pasted with `list=` is trimmed to its video so the
// action stays unambiguous.

import { networkMessage } from "./api.js";
import {
  PICK_MODES,
  defaultMode,
  durationLabel,
  groupFormats,
  infoMessage,
  picksForMode,
  rowDetail,
  rowsForMode,
  videoIdFromInput,
  videoNote,
  watchUrl,
} from "./youtube.js";
import { VideoDownloader } from "./video-download.js";

const ARROW_GLYPH =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4.5v11"/><path d="m7.5 11 4.5 4.5L16.5 11"/><path d="M5 19.5h14"/></svg>';

// One sentence per mode, shown under the picker so "video" versus "merged" is
// never a guess.
const MODE_NOTES = {
  combined: "Picture and sound in one file. Pairs are merged on your computer.",
  video: "Picture only. The audio track is left out.",
  audio: "Sound only, saved as an audio file. Quality sets the bitrate: High 256k · Balanced 192k · Small 128k (File/Page tabs).",
};

export function createVideoPane({ dom, companion, downloads, hooks, getActiveTabUrl, storage }) {
  const downloader = new VideoDownloader({ companion, downloads });
  const $q = (id) => document.getElementById(id);
  const state = {
    url: "",
    video: null,
    groups: null,
    note: "",
    loading: false,
    attempted: false,
    hasFfmpeg: true,
    mode: "combined",
    preferred: "",
    open: false,
  };

  // -------------------------------------------------------------------------
  // Loading
  // -------------------------------------------------------------------------

  async function detect() {
    if (state.url) return;
    let url = "";
    try {
      url = (await getActiveTabUrl()) || "";
    } catch {
      url = "";
    }
    if (!url) return;
    await load(url, { quiet: true });
  }

  /** The companion owns the site registry; this only resolves a paste to its
   *  canonical link. Offline, a plain YouTube link still fills the field so the
   *  "start the companion" note is reachable. */
  async function resolve(raw, { quiet = false } = {}) {
    if (!hooks.isOnline()) {
      const id = videoIdFromInput(raw);
      return id ? watchUrl(id) : null;
    }
    try {
      const found = await companion.detect(raw);
      return found && found.ok && found.url ? found.url : null;
    } catch (error) {
      if (quiet) return null;
      throw error;
    }
  }  async function load(raw, { quiet = false } = {}) {
    // A new paste owns the pane immediately: keeping the previous formats while
    // /detect answers would let a fast click download the previous video.
    if (!quiet) {
      state.loading = true;
      state.url = "";
      state.video = null;
      state.groups = null;
      state.note = "";
      state.open = false;
      hooks.hideError();
      render();
      hooks.refreshPrimary();
    }

    let url;
    try {
      url = await resolve(raw, { quiet });
    } catch (error) {
      state.loading = false;
      render();
      hooks.refreshPrimary();
      hooks.showError(networkMessage(error));
      return;
    }
    if (!url) {
      state.loading = false;
      render();
      hooks.refreshPrimary();
      if (!quiet) {
        hooks.showError("That link isn't a single supported video. Paste a link to a public video.");
      }
      return;
    }

    state.url = url;
    state.video = null;
    state.groups = null;
    state.note = "";
    state.attempted = true;
    dom.videoUrl.value = url;
    hooks.hideError();

    if (!hooks.isOnline()) {
      state.loading = false;
      state.note = "Start the companion app, then read the formats again.";
      render();
      hooks.refreshPrimary();
      return;
    }

    state.loading = true;
    render();
    hooks.refreshPrimary();

    try {
      const info = await companion.info(url);
      if (info && info.ok === true) {
        state.video = info.video || null;
        state.hasFfmpeg = info.hasFfmpeg !== false;
        state.groups = groupFormats(info.formats);
        // `preferred` is empty until storage answers; an empty mode must not
        // win just because rowsForMode treats it as "combined".
        state.mode =
          PICK_MODES.includes(state.preferred) && rowsForMode(state.groups, state.preferred).length
            ? state.preferred
            : defaultMode(state.groups);
        state.open = false;
        state.note = videoNote(info);
      } else {
        state.video = (info && info.video) || null;
        state.hasFfmpeg = !info || info.hasFfmpeg !== false;
        state.groups = null;
        state.open = false;
        state.note = infoMessage(info && info.reason, info && info.error);
      }
    } catch (error) {
      const message = networkMessage(error);
      if (/isn't reachable/i.test(message)) {
        hooks.markOff();
        state.note = message;
      } else {
        hooks.showError(message);
      }
    } finally {
      state.loading = false;
      render();
      hooks.refreshPrimary();
    }
  }

  /** Called after the pill check succeeds, so an offline start self-heals. */
  function onCompanionOnline() {
    if (!state.url || state.groups || state.loading) return;
    if (!state.attempted) return;
    if (!/companion/i.test(state.note)) return;
    void load(state.url);
  }

  // -------------------------------------------------------------------------
  // Downloading
  // -------------------------------------------------------------------------

  // A row is already the whole answer: combined rows carry the audio, video
  // rows are picture only and audio rows are sound only. The picker decides
  // which of those three the user is looking at.
  function picksFor(formatId) {
    const row = findRow(formatId);
    return row ? [row.formatId] : [];
  }

  function findRow(formatId) {
    if (!state.groups) return null;
    const all = [...state.groups.combined, ...state.groups.video, ...state.groups.audio];
    return all.find((row) => row.formatId === formatId) || null;
  }

  async function download(picks) {
    if (downloader.busy || !state.url || !picks.length) return;
    hooks.hideError();
    hooks.setBusy(true);
    hooks.showStatus("preparing", null);

    try {
      await downloader.start({
        url: state.url,
        title: (state.video && state.video.title) || "",
        picks,
        subs: false,
        onUpdate: ({ phase, percent }) => {
          if (phase === "saving") hooks.showStatus("saving", percent, "Saving to your Downloads folder…");
          else if (phase === "preparing") hooks.showStatus("preparing", percent);
        },
      });
      if (downloader.canceled) return;
      hooks.finishSuccess();
    } catch (error) {
      if (downloader.canceled) return;
      const message = networkMessage(error);
      hooks.setBusy(false);
      hooks.hideStatus();
      hooks.showError(message);
      if (/isn't reachable/i.test(message)) hooks.markOff();
    } finally {
      hooks.refreshPrimary();
    }
  }

  function downloadRecommended() {
    void download(picksForMode(state.groups, state.mode, { hasFfmpeg: state.hasFfmpeg }));
  }

  function downloadFormat(formatId) {
    void download(picksFor(formatId));
  }

  async function cancel() {
    await downloader.cancel();
  }

  // -------------------------------------------------------------------------
  // Primary action state (the popup owns the button)
  // -------------------------------------------------------------------------

  function primaryState() {
    if (downloader.busy) {
      return { enabled: false, label: "Working…", hint: "A download is running. Cancel it below." };
    }
    if (state.loading) {
      return { enabled: false, label: "Download", hint: "Reading the available formats…" };
    }
    if (!state.groups) {
      return {
        enabled: false,
        label: "Download",
        hint: state.url
          ? "No formats loaded yet. Paste the link again to retry."
          : "Open a video, or paste a link.",
      };
    }

    const picks = picksForMode(state.groups, state.mode, { hasFfmpeg: state.hasFfmpeg });
    if (!picks.length) {
      return {
        enabled: false,
        label: "Download",
        hint: state.note || "No downloadable format for this video.",
      };
    }
    return {
      enabled: true,
      label: state.mode === "audio" ? "Download audio" : "Download",
      hint: describePicks(picks),
    };
  }

  // The action bar only has room for one short line. The full codec list lives
  // in the What to save card; repeating it here made the footer wrap and read
  // like stray text above the button.
  function describePicks(picks) {
    const first = findRow(picks[0]);
    if (!first) return "Best quality available.";
    const bits = [first.label];
    if (first.sizeLabel) bits.push(first.sizeLabel);
    if (picks.length > 1 || first.merged) bits.push("merged");
    if (state.mode === "video") bits.push("no audio");
    if (state.mode === "audio") bits.push("audio only");
    return `${state.mode === "audio" ? "Saves" : "Saves at"} ${bits.join(" · ")}`;
  }

  // -------------------------------------------------------------------------
  // Rendering
  // -------------------------------------------------------------------------

  function render() {
    const video = state.video;
    dom.videoCard.hidden = !video;
    if (video) {
      dom.videoTitle.textContent = video.title || "Video";
      dom.videoMeta.textContent = [video.author, durationLabel(video.lengthSeconds)]
        .filter(Boolean)
        .join(" · ");
      if (video.thumbnail) {
        dom.videoThumb.src = video.thumbnail;
        dom.videoThumb.hidden = false;
      } else {
        dom.videoThumb.removeAttribute("src");
        dom.videoThumb.hidden = true;
      }
    }

    dom.videoLoading.hidden = !state.loading;
    dom.videoStart.hidden = state.loading || Boolean(state.groups);
    renderOptions();
    renderGroups();
    dom.videoNote.hidden = !state.note;
    dom.videoNote.textContent = state.note;
  }

  // The collapsed bar names what a click would save; expanding it reveals the
  // three choices and the formats behind them.
  function renderOptions() {
    const groups = state.groups;
    dom.videoOptions.hidden = !groups;
    if (!groups) {
      state.open = false;
      return;
    }

    const best = rowsForMode(groups, state.mode)[0] || null;
    dom.optionsValue.textContent = best ? summaryFor(best) : "No formats";
    dom.optionsToggle.setAttribute("aria-expanded", String(state.open));
    dom.optionsToggle.disabled = state.loading;
    dom.optionsBody.hidden = !state.open;
    dom.videoOptions.classList.toggle("is-open", state.open);

    dom.kindChips.querySelectorAll(".chip").forEach((chip) => {
      const mode = chip.dataset.mode;
      const active = mode === state.mode;
      chip.classList.toggle("is-active", active);
      chip.setAttribute("aria-checked", String(active));
      chip.disabled = state.loading || !rowsForMode(groups, mode).length;
    });

    dom.optionsNote.textContent = MODE_NOTES[state.mode] || "";
  }

  function summaryFor(format) {
    const bits = [format.label || "Format"];
    if (format.sizeLabel) bits.push(format.sizeLabel);
    if (format.merged) bits.push("merged");
    return bits.join(" · ");
  }

  function renderGroups() {
    dom.formatGroups.textContent = "";
    const rows = rowsForMode(state.groups, state.mode);
    rows.forEach((row, index) => dom.formatGroups.append(rowFor(row, index === 0)));
  }

  function rowFor(format, isBest) {
    const row = document.createElement("button");
    row.type = "button";
    row.className = isBest ? "format-row is-best" : "format-row";
    row.dataset.formatId = format.formatId;
    const only = state.mode === "video" ? ", video only" : state.mode === "audio" ? ", audio only" : "";
    row.setAttribute("aria-label", `Download ${format.label || "format"}${only}`);

    const main = document.createElement("span");
    main.className = "format-main";
    const label = document.createElement("span");
    label.className = "format-label";
    label.textContent = format.label || "Format";
    if (isBest) {
      const tag = document.createElement("span");
      tag.className = "format-best";
      tag.textContent = "Best";
      label.append(tag);
    }
    const detail = document.createElement("span");
    detail.className = "format-sub";
    detail.textContent = [rowDetail(format), format.merged ? "merged" : ""].filter(Boolean).join(" · ");
    main.append(label, detail);

    const action = document.createElement("span");
    action.className = "format-get";
    action.innerHTML = ARROW_GLYPH;

    row.append(main, action);
    return row;
  }

  // -------------------------------------------------------------------------
  // Wiring
  // -------------------------------------------------------------------------

  function mount() {
    dom.videoLoad.addEventListener("click", () => {
      void load(dom.videoUrl.value);
    });
    dom.videoUrl.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        void load(dom.videoUrl.value);
      }
    });
    dom.videoUrl.addEventListener("input", () => {
      hooks.refreshPrimary();
    });

    dom.optionsToggle.addEventListener("click", () => {
      if (state.loading || !state.groups) return;
      state.open = !state.open;
      renderOptions();
      hooks.refreshPrimary();
    });

    dom.kindChips.addEventListener("click", (event) => {
      const chip = event.target.closest(".chip");
      if (!chip || chip.disabled || !state.groups) return;
      const mode = chip.dataset.mode;
      if (!PICK_MODES.includes(mode) || mode === state.mode) return;
      state.mode = mode;
      state.preferred = mode;
      state.open = true;
      void storage.set({ videoMode: mode });
      renderOptions();
      renderGroups();
      hooks.refreshPrimary();
    });

    dom.formatGroups.addEventListener("click", (event) => {
      const row = event.target.closest(".format-row");
      if (!row || downloader.busy) return;
      downloadFormat(row.dataset.formatId);
    });

    void storage.get(["videoMode"]).then((stored) => {
      const mode = stored && stored.videoMode;
      if (!PICK_MODES.includes(mode)) return;
      state.preferred = mode;
      if (!state.groups || !rowsForMode(state.groups, mode).length) return;
      state.mode = mode;
      renderOptions();
      renderGroups();
      hooks.refreshPrimary();
    });
  }

  return {
    mount,
    detect,
    load,
    downloadRecommended,
    downloadFormat,
    cancel,
    onCompanionOnline,
    primaryState,
    get busy() {
      return downloader.busy;
    },
  };
}
