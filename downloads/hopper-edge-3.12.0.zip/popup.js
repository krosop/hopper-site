import { LocalConverter } from "./local-convert.js";
import { outputName, parseTimeInput } from "./convert-plan.js";
import { clipProblem, clipSegment, mergeProblem } from "./merge-plan.js";
import { fileKind, formatClock, formatDuration, isKnownMedia, readMediaMetadata } from "./media-files.js";
import { Companion, apiErrorText, downloadFailure, networkMessage, publicMessage, timeoutSignal } from "./api.js";
import { createVideoPane } from "./video-pane.js";

// A harness page can point the popup at its own port so a manual check never
// disturbs a companion that is already serving the tray app.
const API = (typeof window !== "undefined" && window.__HOPPER_API) || "http://127.0.0.1:8765";
const MAX_BYTES = 2 * 1024 * 1024 * 1024;
// The wasm build holds the whole input and output in memory, so the in-browser
// path is capped well below the companion's 2 GB.
const LOCAL_MAX_BYTES = 256 * 1024 * 1024;
const POLL_MS = 500;

const FORMATS = {
  mp4: { hint: "MP4 · H.264 + AAC", video: true },
  webm: { hint: "WebM · VP8 + Vorbis", video: true },
  mp3: { hint: "MP3 · audio only", video: false },
  m4a: { hint: "M4A · audio only", video: false },
};

const QUALITIES = {
  high: { hint: "Best detail · larger file" },
  balanced: { hint: "Good detail · normal size" },
  small: { hint: "Softest detail · smallest file" },
};

const VIDEO_GLYPH =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9.5 15 12l-5 2.5z"/></svg>';
const AUDIO_GLYPH =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10.5v3"/><path d="M8 8v8"/><path d="M12 5.5v13"/><path d="M16 8v8"/><path d="M20 10.5v3"/></svg>';
const CHECK_GLYPH =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.4 4.3L19 7.5"/></svg>';

const $ = (id) => document.getElementById(id);

const dom = {
  app: $("app"),
  main: document.querySelector(".main"),
  companionPill: $("companionPill"),
  companionText: $("companionText"),
  tabFile: $("tabFile"),
  tabPage: $("tabPage"),
  tabSlider: $("tabSlider"),
  paneFile: $("paneFile"),
  panePage: $("panePage"),
  dropZone: $("dropZone"),
  dropTitle: $("dropTitle"),
  dropSub: $("dropSub"),
  fileInput: $("fileInput"),
  fileNote: $("fileNote"),
  studio: $("studio"),
  clipList: $("clipList"),
  clipCount: $("clipCount"),
  clearClips: $("clearClips"),
  studioNote: $("studioNote"),
  resultCard: $("resultCard"),
  resultBadge: $("resultBadge"),
  resultName: $("resultName"),
  resultVideo: $("resultVideo"),
  resultAudio: $("resultAudio"),
  resultMeta: $("resultMeta"),
  saveResult: $("saveResult"),
  dismissResult: $("dismissResult"),
  scanButton: $("scanButton"),
  scanLabel: $("scanLabel"),
  mediaList: $("mediaList"),
  pageNote: $("pageNote"),
  urlInput: $("urlInput"),
  formatChips: $("formatChips"),
  qualityChips: $("qualityChips"),
  formatHint: $("formatHint"),
  qualityHint: $("qualityHint"),
  trimControl: $("trimControl"),
  startInput: $("startInput"),
  endInput: $("endInput"),
  resetTrim: $("resetTrim"),
  trimError: $("trimError"),
  statusCard: $("statusCard"),
  statusLabel: $("statusLabel"),
  statusPercent: $("statusPercent"),
  progress: $("progress"),
  progressFill: $("progressFill"),
  statusDetail: $("statusDetail"),
  cancelButton: $("cancelButton"),
  errorCard: $("errorCard"),
  errorText: $("errorText"),
  errorClose: $("errorClose"),
  actionHint: $("actionHint"),
  primaryButton: $("primaryButton"),
  primaryLabel: $("primaryLabel"),
  tabVideo: $("tabVideo"),
  paneVideo: $("paneVideo"),
  controls: $("controls"),
  videoCard: $("videoCard"),
  videoThumb: $("videoThumb"),
  videoTitle: $("videoTitle"),
  videoMeta: $("videoMeta"),
  videoStart: $("videoStart"),
  videoUrl: $("videoUrl"),
  videoLoad: $("videoLoad"),
  videoLoading: $("videoLoading"),
  videoOptions: $("videoOptions"),
  optionsToggle: $("optionsToggle"),
  optionsValue: $("optionsValue"),
  optionsBody: $("optionsBody"),
  optionsNote: $("optionsNote"),
  kindChips: $("kindChips"),
  formatGroups: $("formatGroups"),
  videoNote: $("videoNote"),
};

const TAB_ORDER = ["video", "file", "page"];

function tabButton(name) {
  return name === "video" ? dom.tabVideo : name === "file" ? dom.tabFile : dom.tabPage;
}

const state = {
  tab: "video",
  scrollTops: { video: 0, file: 0, page: 0 },
  clips: [],
  nextClipId: 1,
  reading: 0,
  result: null,
  media: [],
  mediaFresh: false,
  selectedUrl: "",
  format: "mp4",
  quality: "balanced",
  busy: false,
  scanning: false,
  canceling: false,
  health: null,
  healthTimer: null,
  jobId: null,
  jobFilename: "",
  jobConsumed: false,
  jobTimer: null,
  polling: false,
  downloadId: null,
  downloadTimer: null,
  controller: null,
};

const localConvert = new LocalConverter();

// The Video tab owns its own state machine; the popup only lends it the chrome
// wrappers and the shared status/error surfaces.
const videoPane = createVideoPane({
  dom,
  companion: new Companion(API),
  downloads: {
    start: startBrowserDownload,
    search: searchDownload,
    cancel: cancelBrowserDownload,
  },
  getActiveTabUrl: activeTabUrl,
  storage: { get: storageGet, set: storageSet },
  hooks: {
    setBusy,
    showStatus,
    hideStatus,
    showError,
    hideError,
    finishSuccess,
    refreshPrimary: updatePrimary,
    isOnline: companionOnline,
    markOff: markCompanionOff,
  },
});

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function formatBytes(bytes) {
  const value = Number(bytes);
  if (!Number.isFinite(value) || value <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let size = value;
  let unit = 0;
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024;
    unit += 1;
  }
  const digits = size >= 100 || unit === 0 ? 0 : 1;
  return `${size.toFixed(digits)} ${units[unit]}`;
}

function getTrim() {
  const start = parseTimeInput(dom.startInput.value);
  const end = parseTimeInput(dom.endInput.value);

  if (Number.isNaN(start) || Number.isNaN(end)) {
    return { start: null, end: null, error: "Use seconds or m:ss, for example 1:20." };
  }
  if ((start !== null && start < 0) || (end !== null && end < 0)) {
    return { start: null, end: null, error: "Time can't be negative." };
  }
  if (start !== null && end !== null && end <= start) {
    return { start: null, end: null, error: "End has to be after start." };
  }
  return { start, end, error: "" };
}

function syncTrimError() {
  const trim = getTrim();
  dom.trimError.hidden = !trim.error;
  dom.trimError.textContent = trim.error || "";
  return trim;
}

function normalizeHttpUrl(raw) {
  try {
    const url = new URL(String(raw ?? "").trim());
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

function planClip(clip) {
  return {
    input: clip.name,
    start: clip.start,
    end: clip.end,
    duration: clip.duration,
    width: clip.width,
    height: clip.height,
    hasVideo: clip.hasVideo,
    hasAudio: clip.hasAudio,
  };
}

function clipLength(clip) {
  const segment = clipSegment(clip);
  return segment ? segment.duration : 0;
}

function totalLength() {
  return state.clips.reduce((sum, clip) => sum + clipLength(clip), 0);
}

function totalBytes() {
  return state.clips.reduce((sum, clip) => sum + clip.size, 0);
}

function mergeName(format) {
  const date = new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `hopper-studio-${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(
    date.getHours()
  )}${pad(date.getMinutes())}${pad(date.getSeconds())}.${format}`;
}

function ensureFormatForClips() {
  const needsAudio = state.clips.some(
    (clip) => clip.kind === "audio" || (!clip.pending && !clip.unreadable && clip.hasVideo === false)
  );
  if (needsAudio && FORMATS[state.format]?.video) {
    state.format = "mp3";
    persistPrefs();
    syncChips();
  }
}

/** Why one clip cannot become this output, or "" when it can. */
function singleOutputProblem(clip, format) {
  if (!clip || !FORMATS[format]) return "Choose an output format.";
  if (FORMATS[format].video && !clip.hasVideo) return "This clip is audio only. Choose MP3 or M4A.";
  if (!FORMATS[format].video && !clip.hasAudio) {
    return "This clip has no audio track. Choose MP4 or WebM.";
  }
  return "";
}

// networkMessage, apiErrorText and downloadFailure live in api.js so the Video
// pane and the converter share one set of sentences.

// ---------------------------------------------------------------------------
// Chrome wrappers
// ---------------------------------------------------------------------------

function chromeCall(invoke, ...args) {
  return new Promise((resolve, reject) => {
    try {
      invoke(...args, (result) => {
        const error = chrome.runtime && chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else resolve(result);
      });
    } catch (error) {
      reject(error);
    }
  });
}

function queryActiveTab() {
  return chromeCall(
    (query, callback) => chrome.tabs.query(query, callback),
    { active: true, currentWindow: true }
  ).then((tabs) => (Array.isArray(tabs) ? tabs[0] : null));
}

// A harness page can pin the tab URL so auto-detect runs without a real
// YouTube tab. The extension's own pages cannot set this from outside.
function activeTabUrl() {
  const pinned = typeof window !== "undefined" ? window.__HOPPER_ACTIVE_URL : "";
  if (pinned) return Promise.resolve(String(pinned));
  return queryActiveTab().then((tab) => (tab && tab.url) || "");
}

function startBrowserDownload(options) {
  return new Promise((resolve, reject) => {
    try {
      chrome.downloads.download(options, (id) => {
        const error = chrome.runtime && chrome.runtime.lastError;
        if (error) {
          reject(new Error(error.message));
          return;
        }
        if (typeof id !== "number") {
          reject(new Error("The browser didn't start the download."));
          return;
        }
        resolve(id);
      });
    } catch (error) {
      reject(error);
    }
  });
}

function searchDownload(id) {
  return chromeCall((query, callback) => chrome.downloads.search(query, callback), { id });
}

function cancelBrowserDownload(id) {
  return chromeCall((downloadId, callback) => chrome.downloads.cancel(downloadId, callback), id);
}

function storageGet(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(keys, (value) => resolve(value || {}));
    } catch {
      resolve({});
    }
  });
}

function storageSet(value) {
  try {
    chrome.storage.local.set(value);
  } catch {
    /* preferences are a convenience */
  }
}

function persistPrefs() {
  storageSet({ format: state.format, quality: state.quality });
}

// ---------------------------------------------------------------------------
// Companion status
// ---------------------------------------------------------------------------

function setPill(kind, label) {
  dom.companionPill.classList.remove("is-checking", "is-ready", "is-off", "is-warn");
  dom.companionPill.classList.add(`is-${kind}`);
  dom.companionText.textContent = label;
  dom.companionPill.setAttribute("aria-label", `${label}. Click to check again.`);
}

function companionOnline() {
  return Boolean(state.health && state.health.ok);
}

function markCompanionOff() {
  state.health = null;
  setPill("off", "Companion off");
  updatePrimary();
}

async function checkCompanion({ quiet = false } = {}) {
  if (!quiet) setPill("checking", "Checking");
  try {
    const response = await fetch(`${API}/health`, {
      cache: "no-store",
      signal: timeoutSignal(2500),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!data || data.ok !== true) throw new Error("The companion returned an empty status.");
    state.health = data;
    if (data.ffmpeg === false) setPill("warn", "Setup needed");
    else setPill("ready", "Companion ready");
  } catch {
    state.health = null;
    setPill("off", "Companion off");
    if (!quiet && !state.healthTimer) {
      state.healthTimer = window.setTimeout(() => {
        state.healthTimer = null;
        if (!state.health) checkCompanion({ quiet: true });
      }, 1800);
    }
  }
  if (companionOnline()) videoPane.onCompanionOnline();
  updatePrimary();
}

// ---------------------------------------------------------------------------
// Painting
// ---------------------------------------------------------------------------

function syncChips() {
  const audioOnly = state.clips.some(
    (clip) => clip.kind === "audio" || (!clip.pending && !clip.unreadable && clip.hasVideo === false)
  );

  dom.formatChips.querySelectorAll(".chip").forEach((chip) => {
    const format = chip.dataset.format;
    const active = format === state.format;
    chip.classList.toggle("is-active", active);
    chip.setAttribute("aria-checked", String(active));
    chip.disabled = state.busy || (audioOnly && Boolean(FORMATS[format]?.video));
  });

  dom.qualityChips.querySelectorAll(".chip").forEach((chip) => {
    const active = chip.dataset.quality === state.quality;
    chip.classList.toggle("is-active", active);
    chip.setAttribute("aria-checked", String(active));
    chip.disabled = state.busy;
  });

  dom.formatHint.textContent = FORMATS[state.format]?.hint || "";
  dom.qualityHint.textContent = QUALITIES[state.quality]?.hint || "";
}

function syncControls() {
  const locked = state.busy;
  dom.dropZone.setAttribute("aria-disabled", String(locked));
  dom.dropZone.tabIndex = locked ? -1 : 0;
  dom.fileInput.disabled = locked;
  dom.clearClips.disabled = locked || state.clips.length === 0;
  dom.startInput.disabled = locked;
  dom.endInput.disabled = locked;
  dom.resetTrim.disabled = locked;
  dom.scanButton.disabled = locked || state.scanning;
  dom.urlInput.disabled = locked;
  dom.videoUrl.disabled = locked;
  dom.videoLoad.disabled = locked;
  dom.saveResult.disabled = locked || !state.result;
  dom.dismissResult.disabled = locked;
  syncClipControls();
}

function syncClipControls() {
  dom.clipList.querySelectorAll("input, button").forEach((control) => {
    control.disabled = state.busy || control.dataset.blocked === "true";
  });
}

function setBusy(flag) {
  state.busy = flag;
  dom.app.setAttribute("aria-busy", String(flag));
  syncControls();
  syncChips();
  updatePrimary();
}

function setActionHint(text) {
  const next = text || "";
  dom.actionHint.textContent = next;
  dom.actionHint.title = next;
}

function syncScrollState() {
  const main = dom.main;
  if (!main) return;
  const scrollable = main.scrollHeight > main.clientHeight + 2;
  const atBottom = main.scrollTop + main.clientHeight >= main.scrollHeight - 2;
  main.classList.toggle("is-scrollable", scrollable);
  main.classList.toggle("is-at-bottom", scrollable && atBottom);
}

function updatePrimary() {
  if (state.tab === "video") {
    const primary = videoPane.primaryState();
    dom.primaryButton.disabled = !primary.enabled;
    dom.primaryLabel.textContent = primary.label || "Download";
    setActionHint(primary.hint);
    syncScrollState();
    return;
  }

  if (state.tab === "file") {
    const primary = filePrimaryState();
    dom.primaryButton.disabled = !primary.enabled;
    dom.primaryLabel.textContent = primary.label;
    setActionHint(primary.hint);
    syncScrollState();
    return;
  }

  const trim = getTrim();
  let hint = "";
  let enabled = true;

  if (state.busy) {
    hint = "A job is running. You can cancel it below.";
    enabled = false;
  } else if (trim.error) {
    hint = trim.error;
    enabled = false;
  } else if (!companionOnline()) {
    hint = "Start the Hopper companion to fetch a link.";
    enabled = false;
  } else if (state.health.ffmpeg === false) {
    hint = "Install ffmpeg, then restart the companion.";
    enabled = false;
  } else {
    const url = normalizeHttpUrl(dom.urlInput.value || state.selectedUrl);
    if (!url) {
      hint = dom.urlInput.value.trim()
        ? "Enter a direct http(s) media link."
        : "Find a link on this page or paste one.";
      enabled = false;
    } else {
      hint = "Your local companion fetches the link.";
    }
  }

  dom.primaryButton.disabled = !enabled;
  dom.primaryLabel.textContent = state.busy ? "Working…" : "Fetch & convert";
  setActionHint(hint);
  syncScrollState();
}

function filePrimaryState() {
  const clips = state.clips;
  const label = clips.length > 1 ? "Merge & download" : "Convert & download";

  if (state.busy) {
    return { enabled: false, label: "Working…", hint: "A job is running. You can cancel it below." };
  }
  if (!clips.length) {
    return { enabled: false, label, hint: "Add a video or audio file to begin." };
  }
  if (state.reading > 0 || clips.some((clip) => clip.pending)) {
    return { enabled: false, label, hint: "Reading clip details…" };
  }

  const unreadable = clips.filter((clip) => clip.unreadable);
  if (unreadable.length && clips.length > 1) {
    return {
      enabled: false,
      label,
      hint: "Remove the clips whose duration couldn't be read before merging.",
    };
  }

  const trimmed = clips.find((clip) => clip.trimError);
  if (trimmed) return { enabled: false, label, hint: trimmed.trimError };

  if (clips.length === 1) {
    const clip = clips[0];
    const outputProblem = singleOutputProblem(clip, state.format);
    if (outputProblem) return { enabled: false, label, hint: outputProblem };
    if (clip.size > MAX_BYTES) {
      return { enabled: false, label, hint: "That file is larger than 2 GB." };
    }
    if (!companionOnline() && clip.size > LOCAL_MAX_BYTES) {
      return {
        enabled: false,
        label,
        hint: "Files over 256 MB need the Hopper companion.",
      };
    }
    if (clip.unreadable) {
      return {
        enabled: true,
        label,
        hint: "Trim is unavailable for this file. It converts at full length.",
      };
    }
    return {
      enabled: true,
      label,
      hint:
        clip.size > LOCAL_MAX_BYTES
          ? "Large files use the local companion."
          : companionOnline()
            ? "The file stays on your computer."
            : "Converts inside the browser · nothing leaves this device.",
    };
  }

  if (totalBytes() > LOCAL_MAX_BYTES) {
    return {
      enabled: false,
      label,
      hint: "Merging stays under 256 MB total. Remove a clip or convert one at a time.",
    };
  }

  const problem = mergeProblem(clips.map(planClip), state.format);
  if (problem) return { enabled: false, label, hint: problem };

  return {
    enabled: true,
    label,
    hint: `${clips.length} clips · ${formatDuration(totalLength())} · stays on this device.`,
  };
}

function showError(message) {
  dom.errorCard.hidden = false;
  dom.errorText.textContent = publicMessage(message) || "Something went wrong.";
  syncScrollState();
}

function hideError() {
  dom.errorCard.hidden = true;
  dom.errorText.textContent = "";
  syncScrollState();
}

function markOffIfNetwork(error) {
  const message = networkMessage(error);
  if (/isn't reachable|is not reachable/i.test(message)) markCompanionOff();
  return message;
}

// ---------------------------------------------------------------------------
// Status
// ---------------------------------------------------------------------------

const STAGES = {
  preparing: ["Preparing", "Preparing the file on your computer…"],
  uploading: ["Uploading", "Sending the file to the local companion…"],
  fetching: ["Fetching", "Downloading the direct link to your computer…"],
  converting: ["Converting", "ffmpeg is preparing your file…"],
  merging: ["Merging", "Joining the clips on your device…"],
  saving: ["Saving", "Saving the finished file to your Downloads folder…"],
  saved: ["Saved", "Saved to your Downloads folder."],
};

function showStatus(stage, percent, detail) {
  const [label, defaultDetail] = STAGES[stage] || ["Working", "The companion is working…"];
  dom.statusCard.hidden = false;
  dom.statusCard.dataset.stage = stage;
  dom.statusLabel.textContent = label;
  dom.statusDetail.textContent = detail || defaultDetail;
  dom.cancelButton.hidden = stage === "saved";

  if (typeof percent === "number" && Number.isFinite(percent)) {
    const value = Math.max(0, Math.min(100, Math.round(percent)));
    dom.statusPercent.textContent = `${value}%`;
    dom.progress.classList.remove("is-indeterminate");
    dom.progressFill.style.width = `${value}%`;
  } else {
    dom.statusPercent.textContent = "";
    dom.progress.classList.add("is-indeterminate");
    dom.progressFill.style.width = "38%";
  }
  syncScrollState();
}

function hideStatus() {
  dom.statusCard.hidden = true;
  dom.cancelButton.hidden = false;
  dom.progress.classList.remove("is-indeterminate");
  dom.progressFill.style.width = "0%";
  dom.statusLabel.textContent = "Working";
  dom.statusPercent.textContent = "";
  dom.statusDetail.textContent = "";
  delete dom.statusCard.dataset.stage;
  syncScrollState();
}

// ---------------------------------------------------------------------------
// File selection
// ---------------------------------------------------------------------------

function chooseFormat(format) {
  if (state.busy || !FORMATS[format] || format === state.format) return;
  const audioOnly = state.clips.some(
    (clip) => clip.kind === "audio" || (!clip.pending && !clip.unreadable && clip.hasVideo === false)
  );
  if (audioOnly && FORMATS[format].video) return;
  state.format = format;
  clearResult();
  persistPrefs();
  syncChips();
  updatePrimary();
}

function chooseQuality(quality) {
  if (state.busy || !QUALITIES[quality] || quality === state.quality) return;
  state.quality = quality;
  clearResult();
  persistPrefs();
  syncChips();
  updatePrimary();
}

function addFiles(fileList) {
  if (state.busy) return;
  const files = [...(fileList || [])];
  if (!files.length) return;

  hideError();
  const accepted = [];
  const problems = [];

  for (const file of files) {
    if (!file || !file.size) {
      problems.push(`${file?.name || "A file"} is empty.`);
      continue;
    }
    if (file.size > MAX_BYTES) {
      problems.push(`${file.name} is larger than 2 GB.`);
      continue;
    }
    if (!isKnownMedia(file)) {
      problems.push(`${file.name} doesn't look like a video or audio file.`);
      continue;
    }
    accepted.push(file);
  }

  if (accepted.length) {
    clearResult();
    for (const file of accepted) {
      const clip = {
        id: state.nextClipId++,
        file,
        name: file.name,
        size: file.size,
        kind: fileKind(file),
        pending: true,
        unreadable: false,
        duration: null,
        width: 0,
        height: 0,
        hasVideo: false,
        hasAudio: false,
        start: null,
        end: null,
        startText: "",
        endText: "",
        trimError: "",
      };
      state.clips.push(clip);
      loadClipMetadata(clip);
    }
    ensureFormatForClips();
    renderClips();
    updatePrimary();
  }

  if (problems.length) showError(problems.join(" "));
  dom.fileInput.value = "";
}

function loadClipMetadata(clip) {
  state.reading += 1;
  readMediaMetadata(clip.file)
    .then((metadata) => {
      Object.assign(clip, metadata, { pending: false, unreadable: false });
      clip.trimError = clipProblem(planClip(clip));
    })
    .catch(() => {
      clip.pending = false;
      clip.unreadable = true;
      clip.duration = null;
      clip.hasVideo = clip.kind !== "audio";
      clip.hasAudio = clip.kind === "audio";
    })
    .finally(() => {
      state.reading = Math.max(0, state.reading - 1);
      ensureFormatForClips();
      syncChips();
      renderClips();
      updatePrimary();
    });
}

function renderClips() {
  const clips = state.clips;
  dom.studio.hidden = clips.length === 0;
  dom.dropZone.classList.toggle("is-compact", clips.length > 0);
  dom.dropTitle.textContent = clips.length ? "Add more clips" : "Drop video or audio clips";
  dom.dropSub.innerHTML = clips.length
    ? 'or <span class="drop-link">choose more files</span>'
    : 'or <span class="drop-link">choose files</span>';
  dom.clipCount.textContent = clips.length
    ? `${clips.length} clip${clips.length === 1 ? "" : "s"}${
        clips.some((clip) => clip.pending) ? "" : ` · ${formatDuration(totalLength())}`
      }`
    : "";
  dom.clearClips.disabled = state.busy || clips.length === 0;

  dom.clipList.textContent = "";
  clips.forEach((clip, index) => {
    dom.clipList.appendChild(clipRow(clip, index));
  });

  if (!clips.length) {
    dom.studioNote.textContent = "Each clip keeps its own trim. Merge joins them in this order.";
  } else if (clips.length === 1) {
    dom.studioNote.textContent = clips[0].unreadable
      ? "This clip can still convert on its own; trim and merge need a readable duration."
      : "Trim this clip, then convert it. Add another clip to merge them.";
  } else if (clips.some((clip) => clip.unreadable)) {
    dom.studioNote.textContent = "A clip without a readable duration can only be converted alone.";
  } else {
    dom.studioNote.textContent = "Merge joins these clips in order. Each keeps its own trim.";
  }
}

function clipRow(clip, index) {
  const row = document.createElement("li");
  row.className = "clip-row";
  row.dataset.id = String(clip.id);

  const main = document.createElement("div");
  main.className = "clip-main";

  const number = document.createElement("span");
  number.className = "clip-index";
  number.textContent = String(index + 1);

  const glyph = document.createElement("span");
  glyph.className = "clip-glyph";
  glyph.setAttribute("aria-hidden", "true");
  glyph.innerHTML = clip.kind === "audio" ? AUDIO_GLYPH : VIDEO_GLYPH;

  const copy = document.createElement("span");
  copy.className = "clip-copy";
  const name = document.createElement("span");
  name.className = "clip-name";
  name.textContent = clip.name;
  name.title = clip.name;
  const meta = document.createElement("span");
  meta.className = "clip-meta";
  meta.textContent = clipMeta(clip);
  copy.append(name, meta);

  const actions = document.createElement("span");
  actions.className = "clip-actions";
  actions.append(
    clipAction(clip, index, "up", "↑", "Move up", index === 0),
    clipAction(clip, index, "down", "↓", "Move down", index === state.clips.length - 1),
    clipAction(clip, index, "remove", "×", "Remove", false)
  );

  main.append(number, glyph, copy, actions);
  row.appendChild(main);

  if (!clip.pending && !clip.unreadable) {
    const trim = document.createElement("div");
    trim.className = "clip-trim";
    const start = clipTimeInput(clip, "start", "0:00");
    const dash = document.createElement("span");
    dash.className = "dash";
    dash.setAttribute("aria-hidden", "true");
    dash.textContent = "–";
    const end = clipTimeInput(clip, "end", formatClock(clip.duration));
    const full = document.createElement("button");
    full.type = "button";
    full.className = "link";
    full.textContent = "Full";
    full.title = "Use the whole clip";
    full.disabled = state.busy;
    full.addEventListener("click", () => resetClipTrim(clip));
    trim.append(start, dash, end, full);
    row.appendChild(trim);
  }

  const error = document.createElement("p");
  error.className = "clip-error";
  if (clip.pending) {
    error.textContent = "Reading clip details…";
    error.hidden = false;
  } else if (clip.unreadable) {
    error.textContent = "Trim and merge need a readable duration. This clip can still convert alone.";
    error.hidden = false;
  } else {
    error.textContent = clip.trimError;
    error.hidden = !clip.trimError;
  }
  row.appendChild(error);

  return row;
}

function clipMeta(clip) {
  if (clip.pending) return "Reading clip…";
  if (clip.unreadable) return `${formatBytes(clip.size)} · duration unavailable`;
  return [
    formatDuration(clip.duration),
    clip.hasVideo ? `${clip.width}×${clip.height}` : "Audio",
    clip.hasVideo ? (clip.hasAudio ? "Sound" : "Silent") : "",
    formatBytes(clip.size),
  ]
    .filter(Boolean)
    .join(" · ");
}

function clipAction(clip, index, action, glyph, label, blocked) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "icon-btn";
  button.textContent = glyph;
  button.title = label;
  button.setAttribute("aria-label", `${label} clip ${index + 1}`);
  button.dataset.act = action;
  button.dataset.blocked = String(blocked);
  button.disabled = state.busy || blocked;
  button.addEventListener("click", () => {
    if (action === "up") moveClip(clip.id, -1);
    else if (action === "down") moveClip(clip.id, 1);
    else removeClip(clip.id);
  });
  return button;
}

function clipTimeInput(clip, field, placeholder) {
  const label = document.createElement("label");
  label.className = "clip-time";
  const tag = document.createElement("span");
  tag.textContent = field === "start" ? "Start" : "End";
  const input = document.createElement("input");
  input.type = "text";
  input.inputMode = "numeric";
  input.placeholder = placeholder;
  input.autocomplete = "off";
  input.value = field === "start" ? clip.startText : clip.endText;
  input.disabled = state.busy;
  input.setAttribute("aria-label", `${field === "start" ? "Start" : "End"} for ${clip.name}`);
  input.addEventListener("input", () => {
    if (state.result) clearResult();
    if (field === "start") clip.startText = input.value;
    else clip.endText = input.value;
    const start = parseTimeInput(clip.startText);
    const end = parseTimeInput(clip.endText);
    clip.start = Number.isNaN(start) ? NaN : start;
    clip.end = Number.isNaN(end) ? NaN : end;
    clip.trimError = clipProblem(planClip(clip));
    const error = label.closest(".clip-row")?.querySelector(".clip-error");
    if (error) {
      error.textContent = clip.trimError;
      error.hidden = !clip.trimError;
    }
    updatePrimary();
  });
  label.append(tag, input);
  return label;
}

function resetClipTrim(clip) {
  if (state.busy) return;
  clip.startText = "";
  clip.endText = "";
  clip.start = null;
  clip.end = null;
  clip.trimError = "";
  clearResult();
  renderClips();
  updatePrimary();
}

function removeClip(id) {
  if (state.busy) return;
  state.clips = state.clips.filter((clip) => clip.id !== id);
  clearResult();
  renderClips();
  syncChips();
  updatePrimary();
}

function moveClip(id, delta) {
  if (state.busy) return;
  const index = state.clips.findIndex((clip) => clip.id === id);
  const target = index + delta;
  if (index < 0 || target < 0 || target >= state.clips.length) return;
  const [clip] = state.clips.splice(index, 1);
  state.clips.splice(target, 0, clip);
  clearResult();
  renderClips();
  updatePrimary();
}

function clearClips() {
  if (state.busy) return;
  state.clips = [];
  state.reading = 0;
  clearResult();
  renderClips();
  syncChips();
  updatePrimary();
}

// ---------------------------------------------------------------------------
// Page scanning
// ---------------------------------------------------------------------------

// This function is serialized into the active tab. Keep it self-contained:
// no outer variables, no helper functions.
function scanPageMedia() {
  const found = [];
  const add = (value, kind) => {
    if (!value) return;
    try {
      const url = new URL(value, location.href);
      if (url.protocol !== "http:" && url.protocol !== "https:") return;
      found.push({ url: url.href, kind });
    } catch {
      /* ignore malformed URLs */
    }
  };

  document.querySelectorAll("video, audio").forEach((node) => {
    const kind = node.tagName === "VIDEO" ? "video" : "audio";
    add(node.currentSrc, kind);
    add(node.getAttribute("src"), kind);
    node.querySelectorAll("source[src]").forEach((source) => {
      add(source.getAttribute("src"), kind);
    });
  });

  return found.slice(0, 20);
}

function setScanning(flag) {
  state.scanning = flag;
  dom.scanLabel.textContent = flag ? "Scanning…" : "Find media on this page";
  syncControls();
}

function mediaName(url) {
  try {
    const parsed = new URL(url);
    const last = parsed.pathname.split("/").filter(Boolean).pop() || "";
    return decodeURIComponent(last) || parsed.hostname;
  } catch {
    return url;
  }
}

function mediaHost(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

function renderMedia() {
  dom.mediaList.textContent = "";
  if (!state.media.length) {
    dom.mediaList.hidden = true;
    state.mediaFresh = false;
    return;
  }

  const animate = state.mediaFresh;
  state.mediaFresh = false;
  state.media.forEach((media, index) => {
    const row = document.createElement("button");
    row.type = "button";
    row.dataset.url = media.url;
    row.className = `media-row${media.url === state.selectedUrl ? " is-selected" : ""}${
      animate ? " is-enter" : ""
    }`;
    if (animate) row.style.setProperty("--i", String(Math.min(index, 7)));
    row.setAttribute("aria-pressed", String(media.url === state.selectedUrl));

    const kind = document.createElement("span");
    kind.className = "kind";
    kind.textContent = media.kind === "audio" ? "Audio" : "Video";

    const copy = document.createElement("span");
    copy.className = "media-copy";
    const name = document.createElement("span");
    name.className = "media-name";
    name.textContent = mediaName(media.url);
    const host = document.createElement("span");
    host.className = "media-host";
    host.textContent = mediaHost(media.url);
    copy.append(name, host);

    const check = document.createElement("span");
    check.className = "check";
    check.innerHTML = CHECK_GLYPH;

    row.append(kind, copy, check);
    row.addEventListener("click", () => selectMedia(media));
    dom.mediaList.appendChild(row);
  });

  dom.mediaList.hidden = false;
}

// Selecting a row must not rebuild the list: rebuilding drops keyboard focus
// and replays every entrance. Only the two states that changed need painting.
function syncMediaSelection() {
  dom.mediaList.querySelectorAll(".media-row").forEach((row) => {
    const selected = row.dataset.url === state.selectedUrl;
    row.classList.toggle("is-selected", selected);
    row.setAttribute("aria-pressed", String(selected));
  });
}

function selectMedia(media) {
  state.selectedUrl = media.url;
  dom.urlInput.value = media.url;
  dom.pageNote.hidden = true;
  dom.mediaList.hidden = state.media.length === 0;
  syncMediaSelection();
  updatePrimary();
}

function scanErrorMessage(error) {
  const text = String((error && error.message) || error || "");
  if (
    /cannot access|extensions gallery|chrome:\/\/|edge:\/\/|missing host permission|the extensions gallery cannot be scripted|cannot be scripted/i.test(
      text
    )
  ) {
    return "This page doesn't allow scanning. Paste a direct media link instead.";
  }
  return text || "Couldn't scan this page.";
}

async function scanPage() {
  if (state.busy || state.scanning) return;
  hideError();
  setScanning(true);

  try {
    const tab = await queryActiveTab();
    if (!tab || typeof tab.id !== "number") throw new Error("Open a page first.");
    if (!chrome.scripting || typeof chrome.scripting.executeScript !== "function") {
      throw new Error("This browser can't scan pages.");
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scanPageMedia,
    });
    const raw = results && results[0] && Array.isArray(results[0].result) ? results[0].result : [];

    const seen = new Set();
    const media = [];
    raw.forEach((item) => {
      const url = normalizeHttpUrl(item && item.url);
      if (!url || seen.has(url)) return;
      seen.add(url);
      media.push({ url, kind: item.kind === "audio" ? "audio" : "video" });
    });

    state.media = media;
    state.mediaFresh = true;
    state.selectedUrl = "";

    if (media.length) {
      dom.pageNote.hidden = true;
      // Build the rows once for this scan; selecting a row later only moves
      // the selected state, so a click never destroys the list or its focus.
      renderMedia();
      selectMedia(media[0]);
    } else {
      dom.mediaList.hidden = true;
      dom.pageNote.hidden = false;
      dom.pageNote.textContent =
        "No direct media link was found. Protected streams and blob links can't be fetched — paste a direct .mp4, .webm or audio link instead.";
      dom.urlInput.value = "";
      updatePrimary();
    }
  } catch (error) {
    state.media = [];
    state.selectedUrl = "";
    renderMedia();
    dom.pageNote.hidden = false;
    dom.pageNote.textContent =
      "This page doesn't allow scanning. Paste a direct media link instead.";
    showError(scanErrorMessage(error));
  } finally {
    setScanning(false);
  }
}

// ---------------------------------------------------------------------------
// Jobs
// ---------------------------------------------------------------------------

function stopJobPolling() {
  if (state.jobTimer) {
    clearInterval(state.jobTimer);
    state.jobTimer = null;
  }
}

function stopDownloadPolling() {
  if (state.downloadTimer) {
    clearInterval(state.downloadTimer);
    state.downloadTimer = null;
  }
}

function resetRun() {
  state.busy = false;
  state.jobId = null;
  state.jobConsumed = false;
  state.downloadId = null;
  state.controller = null;
  dom.app.setAttribute("aria-busy", "false");
  syncControls();
  syncChips();
  updatePrimary();
}

function startJob(jobId, filename, stage) {
  if (!jobId) {
    resetRun();
    hideStatus();
    showError("The companion didn't return a job. Try again.");
    return;
  }
  state.jobId = jobId;
  state.jobFilename = filename || "";
  state.jobConsumed = false;
  setBusy(true);
  showStatus(stage || "converting", null);
  stopJobPolling();
  state.jobTimer = window.setInterval(() => {
    void pollJob();
  }, POLL_MS);
  void pollJob();
}

async function pollJob() {
  if (!state.jobId || state.polling) return;
  state.polling = true;
  const jobId = state.jobId;

  try {
    const response = await fetch(`${API}/job/${encodeURIComponent(jobId)}`, {
      cache: "no-store",
      signal: timeoutSignal(6000),
    });
    if (!response.ok) throw new Error(await apiErrorText(response));

    const job = await response.json();
    if (!job || job.ok === false) throw new Error((job && job.error) || "Empty job status.");

    if (job.state === "error" || job.state === "canceled") {
      stopJobPolling();
      resetRun();
      hideStatus();
      showError(job.error || "The conversion was canceled.");
      return;
    }
    if (job.state === "done") {
      stopJobPolling();
      finishSuccess();
      return;
    }
    if (job.state === "ready") {
      stopJobPolling();
      await downloadJob(job);
      return;
    }

    showStatus(job.stage || "converting", job.percent);
  } catch (error) {
    stopJobPolling();
    resetRun();
    hideStatus();
    showError(markOffIfNetwork(error));
  } finally {
    state.polling = false;
  }
}

async function downloadJob(job) {
  if (!state.jobId) return;
  state.jobConsumed = true;
  const filename = job.filename || state.jobFilename || "hopper-download";

  try {
    const id = await startBrowserDownload({
      url: `${API}/stream?job=${encodeURIComponent(state.jobId)}`,
      filename,
      saveAs: false,
      conflictAction: "uniquify",
    });
    state.downloadId = id;
    showStatus("saving", 100);
    stopDownloadPolling();
    state.downloadTimer = window.setInterval(() => {
      void pollDownload();
    }, POLL_MS);
    void pollDownload();
  } catch (error) {
    state.jobConsumed = false;
    resetRun();
    hideStatus();
    showError(`The browser couldn't start the download: ${error.message}`);
  }
}

async function pollDownload() {
  if (state.downloadId === null) return;
  const id = state.downloadId;

  try {
    const items = await searchDownload(id);
    const item = Array.isArray(items) ? items[0] : null;
    if (!item) {
      stopDownloadPolling();
      resetRun();
      hideStatus();
      return;
    }

    if (item.state === "complete") {
      stopDownloadPolling();
      finishSuccess();
      return;
    }
    if (item.state === "interrupted") {
      stopDownloadPolling();
      const message = downloadFailure(item.error);
      resetRun();
      hideStatus();
      showError(message);
      return;
    }

    const total = Number(item.totalBytes) || 0;
    const received = Number(item.bytesReceived) || 0;
    const percent = total > 0 ? Math.min(99, Math.round((received / total) * 100)) : null;
    showStatus("saving", percent);
  } catch (error) {
    stopDownloadPolling();
    resetRun();
    hideStatus();
    showError(networkMessage(error));
  }
}

function finishSuccess() {
  stopJobPolling();
  stopDownloadPolling();
  state.busy = false;
  state.jobId = null;
  state.jobConsumed = false;
  state.downloadId = null;
  state.controller = null;
  dom.app.setAttribute("aria-busy", "false");
  syncControls();
  syncChips();
  if (state.result) dom.resultBadge.textContent = "Saved";
  showStatus("saved", 100);
  updatePrimary();
  window.setTimeout(() => {
    if (!state.busy) hideStatus();
  }, 2800);
}

async function cancelCurrent() {
  const jobId = state.jobId;
  const downloadId = state.downloadId;
  state.canceling = true;

  stopJobPolling();
  stopDownloadPolling();
  localConvert.cancel();
  await videoPane.cancel();

  if (state.controller) {
    try {
      state.controller.abort();
    } catch {
      /* already aborted */
    }
  }
  if (downloadId !== null) {
    try {
      await cancelBrowserDownload(downloadId);
    } catch {
      /* the download may already be gone */
    }
  }
  if (jobId) {
    try {
      await fetch(`${API}/job/${encodeURIComponent(jobId)}`, {
        method: "DELETE",
        signal: timeoutSignal(4000),
      });
    } catch {
      /* the job may already be gone */
    }
  }

  resetRun();
  hideStatus();
  hideError();
}

// ---------------------------------------------------------------------------
// Runs
// ---------------------------------------------------------------------------

function clearResult() {
  const result = state.result;
  state.result = null;
  dom.resultCard.hidden = true;
  dom.resultBadge.textContent = "Ready";
  dom.resultName.textContent = "";
  dom.resultName.removeAttribute("title");
  dom.resultMeta.textContent = "";
  dom.resultVideo.pause?.();
  dom.resultVideo.removeAttribute("src");
  dom.resultVideo.hidden = true;
  try {
    dom.resultVideo.load();
  } catch {
    /* the element is already detached */
  }
  dom.resultAudio.pause?.();
  dom.resultAudio.removeAttribute("src");
  dom.resultAudio.hidden = true;
  try {
    dom.resultAudio.load();
  } catch {
    /* the element is already detached */
  }
  if (result) {
    try {
      URL.revokeObjectURL(result.url);
    } catch {
      /* already released */
    }
  }
  dom.saveResult.disabled = true;
  dom.dismissResult.disabled = true;
  syncScrollState();
}

function showResult({ blob, name, format, duration }) {
  clearResult();
  const url = URL.createObjectURL(blob);
  state.result = { blob, url, name, format, duration };
  const video = format === "mp4" || format === "webm";

  dom.resultCard.hidden = false;
  dom.resultBadge.textContent = "Ready";
  dom.resultName.textContent = name;
  dom.resultName.title = name;
  dom.resultMeta.textContent = [
    formatBytes(blob.size),
    duration > 0 ? formatDuration(duration) : "",
    format.toUpperCase(),
  ]
    .filter(Boolean)
    .join(" · ");
  dom.resultVideo.hidden = !video;
  dom.resultAudio.hidden = video;
  if (video) dom.resultVideo.src = url;
  else dom.resultAudio.src = url;
  dom.saveResult.disabled = state.busy;
  dom.dismissResult.disabled = state.busy;
  dom.resultCard.scrollIntoView?.({ block: "nearest" });
  syncScrollState();
}

async function startResultDownload() {
  if (!state.result) return false;
  const { url, name } = state.result;
  try {
    const id = await startBrowserDownload({
      url,
      filename: name,
      saveAs: false,
      conflictAction: "uniquify",
    });
    state.downloadId = id;
    dom.resultBadge.textContent = "Saving";
    showStatus("saving", 100, "Saving the finished file to your Downloads folder…");
    stopDownloadPolling();
    state.downloadTimer = window.setInterval(() => {
      void pollDownload();
    }, POLL_MS);
    void pollDownload();
    return true;
  } catch (error) {
    resetRun();
    hideStatus();
    showError(`The browser couldn't start the download: ${error.message}`);
    return false;
  }
}

async function saveResultAgain() {
  if (!state.result || state.busy) return;
  hideError();
  state.canceling = false;
  setBusy(true);
  showStatus("saving", null, "Saving the finished file…");
  await startResultDownload();
}

async function runFile() {
  if (state.busy) return;
  const clips = state.clips;
  if (!clips.length) return;
  if (state.reading > 0 || clips.some((clip) => clip.pending)) return;

  const trimmed = clips.find((clip) => clip.trimError);
  if (trimmed) {
    showError(trimmed.trimError);
    return;
  }
  if (clips.length > 1 && clips.some((clip) => clip.unreadable)) {
    showError("Remove the clips whose duration couldn't be read before merging.");
    return;
  }
  if (clips.length === 1) {
    const outputProblem = singleOutputProblem(clips[0], state.format);
    if (outputProblem) {
      showError(outputProblem);
      return;
    }
  }

  clearResult();
  state.canceling = false;

  if (clips.length === 1) {
    const clip = clips[0];
    if (clip.size > LOCAL_MAX_BYTES) return runCompanionFile(clip);
    return runLocalFile(clip);
  }

  return runLocalMerge();
}

async function runLocalFile(clip) {
  hideError();
  setBusy(true);
  const detail = `Converting ${clip.name} on this device…`;
  showStatus("converting", null, detail);

  try {
    const { blob } = await localConvert.convert({
      file: clip.file,
      format: state.format,
      quality: state.quality,
      start: clip.unreadable ? null : clip.start,
      end: clip.unreadable ? null : clip.end,
      onProgress: (percent) => {
        if (state.busy) showStatus("converting", percent, detail);
      },
    });
    if (state.canceling) return;

    showResult({
      blob,
      name: outputName(clip.name, state.format),
      format: state.format,
      duration: clipLength(clip),
    });
    await startResultDownload();
  } catch (error) {
    if (state.canceling) return;
    resetRun();
    hideStatus();
    showError(error && error.message ? error.message : "The conversion failed.");
  }
}

async function runLocalMerge() {
  const clips = state.clips;
  const problem = mergeProblem(clips.map(planClip), state.format);
  if (problem) {
    showError(problem);
    return;
  }
  if (totalBytes() > LOCAL_MAX_BYTES) {
    showError("Merging stays under 256 MB total. Remove a clip or convert one at a time.");
    return;
  }

  hideError();
  setBusy(true);
  const detail = `Merging ${clips.length} clips on this device…`;
  showStatus("merging", null, detail);

  try {
    const { blob } = await localConvert.merge({
      clips: clips.map((clip) => ({
        file: clip.file,
        start: clip.start,
        end: clip.end,
        duration: clip.duration,
        width: clip.width,
        height: clip.height,
        hasVideo: clip.hasVideo,
        hasAudio: clip.hasAudio,
      })),
      format: state.format,
      quality: state.quality,
      onProgress: (percent) => {
        if (state.busy) showStatus("merging", percent, detail);
      },
    });
    if (state.canceling) return;

    showResult({
      blob,
      name: mergeName(state.format),
      format: state.format,
      duration: totalLength(),
    });
    await startResultDownload();
  } catch (error) {
    if (state.canceling) return;
    resetRun();
    hideStatus();
    showError(error && error.message ? error.message : "The merge failed.");
  }
}

async function runCompanionFile(clip) {
  if (!clip || state.busy) return;
  if (clip.size > MAX_BYTES) {
    showError("That file is larger than 2 GB. Choose a smaller file.");
    return;
  }

  hideError();
  state.canceling = false;
  setBusy(true);
  showStatus("uploading", null, `Sending ${clip.name} to the local companion…`);

  const params = new URLSearchParams({ format: state.format, quality: state.quality });
  if (!clip.unreadable && clip.start !== null && clip.start > 0) params.set("start", String(clip.start));
  if (!clip.unreadable && clip.end !== null) params.set("end", String(clip.end));

  const controller = new AbortController();
  state.controller = controller;
  const timeout = window.setTimeout(() => {
    try {
      controller.abort();
    } catch {
      /* already aborted */
    }
  }, 30 * 60 * 1000);

  try {
    const response = await fetch(`${API}/convert?${params.toString()}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/octet-stream",
        "X-Filename": encodeURIComponent(clip.name),
      },
      body: clip.file,
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(await apiErrorText(response));

    const data = await response.json();
    if (!data || data.ok !== true || !data.jobId) {
      throw new Error((data && data.error) || "The companion couldn't start this conversion.");
    }
    startJob(data.jobId, data.filename, "uploading");
  } catch (error) {
    if (state.canceling) return;
    resetRun();
    hideStatus();
    const message =
      error && error.name === "AbortError"
        ? "The upload timed out. Check the companion and try a smaller file."
        : markOffIfNetwork(error);
    showError(message);
  } finally {
    window.clearTimeout(timeout);
  }
}

async function runFetch() {
  if (state.busy) return;
  const url = normalizeHttpUrl(dom.urlInput.value || state.selectedUrl);
  if (!url) {
    showError("Paste a direct http(s) media link.");
    return;
  }
  const trim = syncTrimError();
  if (trim.error) {
    showError(trim.error);
    return;
  }

  hideError();
  state.canceling = false;
  setBusy(true);
  showStatus("fetching", null);

  const body = { url, format: state.format, quality: state.quality };
  if (trim.start !== null && trim.start > 0) body.start = trim.start;
  if (trim.end !== null) body.end = trim.end;

  const controller = new AbortController();
  state.controller = controller;

  try {
    const response = await fetch(`${API}/fetch`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(await apiErrorText(response));

    const data = await response.json();
    if (!data || data.ok !== true || !data.jobId) {
      throw new Error((data && data.error) || "The companion couldn't start this job.");
    }
    startJob(data.jobId, data.filename, "fetching");
  } catch (error) {
    if (state.canceling) return;
    resetRun();
    hideStatus();
    showError(markOffIfNetwork(error));
  }
}

// ---------------------------------------------------------------------------
// Tabs and wiring
// ---------------------------------------------------------------------------

function setTab(tab, { focus = false } = {}) {
  if (!TAB_ORDER.includes(tab)) return;
  const previous = state.tab;
  if (dom.main && previous !== tab) state.scrollTops[previous] = dom.main.scrollTop;
  state.tab = tab;
  const index = TAB_ORDER.indexOf(tab);

  TAB_ORDER.forEach((name) => {
    const active = name === tab;
    tabButton(name).classList.toggle("is-active", active);
    tabButton(name).setAttribute("aria-selected", String(active));
    tabButton(name).tabIndex = active ? 0 : -1;
  });

  // The slider is exactly one tab wide, so each step is its own width. An
  // extra 2px here used to leave File and Page visibly off-centre.
  dom.tabSlider.style.transform =
    index === 0 ? "translateX(0)" : `translateX(${index * 100}%)`;

  dom.paneVideo.hidden = tab !== "video";
  dom.paneFile.hidden = tab !== "file";
  dom.panePage.hidden = tab !== "page";
  dom.controls.hidden = tab === "video";
  dom.trimControl.hidden = tab === "file";
  // The panes share one scroller. Without this, leaving the tall Video tab
  // scrolled down opens File or Page halfway down, with its heading cut off.
  if (dom.main) dom.main.scrollTop = state.scrollTops[tab] || 0;

  // One coordinated entrance per switch: retarget from current position so
  // rapid tab changes feel physical instead of replaying a full stagger.
  const activePane = tab === "video" ? dom.paneVideo : tab === "file" ? dom.paneFile : dom.panePage;
  if (activePane && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    activePane.classList.remove("is-switching");
    void activePane.offsetWidth;
    activePane.classList.add("is-switching");
    window.clearTimeout(activePane._switchTimer);
    activePane._switchTimer = window.setTimeout(() => activePane.classList.remove("is-switching"), 220);
  }

  if (focus) tabButton(tab).focus();
  hideError();
  updatePrimary();
}

function moveTab(direction) {
  const index = TAB_ORDER.indexOf(state.tab);
  const step = direction === "next" ? 1 : TAB_ORDER.length - 1;
  setTab(TAB_ORDER[(index + step) % TAB_ORDER.length], { focus: true });
}

function wire() {
  dom.companionPill.addEventListener("click", () => {
    void checkCompanion();
  });

  TAB_ORDER.forEach((name) => {
    const tab = tabButton(name);
    tab.addEventListener("click", () => {
      setTab(name);
    });
    tab.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight" || event.key === "ArrowDown") {
        event.preventDefault();
        moveTab("next");
      } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
        event.preventDefault();
        moveTab("previous");
      } else if (event.key === "Home") {
        event.preventDefault();
        setTab(TAB_ORDER[0], { focus: true });
      } else if (event.key === "End") {
        event.preventDefault();
        setTab(TAB_ORDER[TAB_ORDER.length - 1], { focus: true });
      }
    });
  });

  dom.dropZone.addEventListener("click", () => {
    if (!state.busy) dom.fileInput.click();
  });
  dom.dropZone.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      if (!state.busy) dom.fileInput.click();
    }
  });

  ["dragenter", "dragover"].forEach((type) => {
    dom.dropZone.addEventListener(type, (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!state.busy) dom.dropZone.classList.add("is-dragging");
    });
  });
  ["dragleave", "dragend"].forEach((type) => {
    dom.dropZone.addEventListener(type, () => {
      dom.dropZone.classList.remove("is-dragging");
    });
  });
  dom.dropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    event.stopPropagation();
    dom.dropZone.classList.remove("is-dragging");
    if (state.busy) return;
    addFiles(event.dataTransfer && event.dataTransfer.files);
  });

  dom.fileInput.addEventListener("change", () => {
    addFiles(dom.fileInput.files);
  });
  dom.clearClips.addEventListener("click", clearClips);
  dom.saveResult.addEventListener("click", () => {
    void saveResultAgain();
  });
  dom.dismissResult.addEventListener("click", clearResult);

  dom.formatChips.addEventListener("click", (event) => {
    const chip = event.target.closest(".chip");
    if (!chip || chip.disabled) return;
    chooseFormat(chip.dataset.format);
  });
  dom.qualityChips.addEventListener("click", (event) => {
    const chip = event.target.closest(".chip");
    if (!chip || chip.disabled) return;
    chooseQuality(chip.dataset.quality);
  });

  [dom.startInput, dom.endInput].forEach((input) => {
    input.addEventListener("input", () => {
      syncTrimError();
      updatePrimary();
    });
    input.addEventListener("blur", () => {
      syncTrimError();
      updatePrimary();
    });
  });
  dom.resetTrim.addEventListener("click", () => {
    if (state.busy) return;
    dom.startInput.value = "";
    dom.endInput.value = "";
    syncTrimError();
    updatePrimary();
  });

  dom.scanButton.addEventListener("click", () => {
    void scanPage();
  });
  dom.main.addEventListener("scroll", syncScrollState, { passive: true });
  dom.urlInput.addEventListener("input", () => {
    state.selectedUrl = "";
    dom.mediaList.querySelectorAll(".media-row").forEach((row) => {
      row.classList.remove("is-selected");
      row.setAttribute("aria-pressed", "false");
    });
    updatePrimary();
  });

  dom.primaryButton.addEventListener("click", () => {
    if (state.tab === "video") videoPane.downloadRecommended();
    else if (state.tab === "file") void runFile();
    else void runFetch();
  });
  dom.cancelButton.addEventListener("click", () => {
    void cancelCurrent();
  });
  dom.errorClose.addEventListener("click", hideError);

  document.addEventListener("dragover", (event) => event.preventDefault());
  document.addEventListener("drop", (event) => event.preventDefault());

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      if (!dom.errorCard.hidden) {
        hideError();
        return;
      }
      window.close();
    }
    if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
      if (!dom.primaryButton.disabled) dom.primaryButton.click();
    }
  });

  window.addEventListener("pagehide", () => {
    stopJobPolling();
    stopDownloadPolling();
    void videoPane.cancel();
    if (state.controller) {
      try {
        state.controller.abort();
      } catch {
        /* already aborted */
      }
    }
    if (state.jobId && !state.jobConsumed) {
      try {
        void fetch(`${API}/job/${encodeURIComponent(state.jobId)}`, {
          method: "DELETE",
          keepalive: true,
        }).catch(() => {});
      } catch {
        /* the server will reap it */
      }
    }
  });
}

// Theme ---------------------------------------------------------------
// Dark is the default. The header toggle flips a data attribute on <html> so
// every surface switches at once, and remembers the choice locally.

const THEME_KEY = "hopper-theme";

function applyTheme(theme) {
  const next = theme === "light" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  const toggle = document.getElementById("themeToggle");
  if (toggle) toggle.setAttribute("aria-pressed", String(next === "light"));
}

function wireTheme() {
  let stored = null;
  try {
    stored = localStorage.getItem(THEME_KEY);
  } catch {
    /* storage can be unavailable; dark still applies */
  }
  applyTheme(stored === "light" ? "light" : "dark");

  const toggle = document.getElementById("themeToggle");
  if (!toggle) return;
  toggle.addEventListener("click", () => {
    const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
    applyTheme(next);
    try {
      localStorage.setItem(THEME_KEY, next);
    } catch {
      /* the choice just will not survive a reopen */
    }
  });
}

async function init() {
  wireTheme();
  videoPane.mount();
  wire();
  setTab("video");
  if (typeof ResizeObserver === "function") {
    new ResizeObserver(syncScrollState).observe(dom.main);
  }

  const stored = await storageGet(["format", "quality"]);
  if (FORMATS[stored.format]) state.format = stored.format;
  if (QUALITIES[stored.quality]) state.quality = stored.quality;

  renderClips();
  clearResult();
  syncChips();
  syncControls();
  updatePrimary();

  // The health check decides whether the Video tab can read formats, so the
  // auto-detect runs after it instead of racing it.
  void checkCompanion().then(() => {
    void videoPane.detect();
  });
}

init().catch((error) => {
  showError(networkMessage(error));
});
